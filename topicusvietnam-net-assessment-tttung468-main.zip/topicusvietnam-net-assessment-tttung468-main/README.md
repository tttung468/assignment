# Assessment Backend Developer

This repository is a **take-home assessment** for backend developer candidates. It contains a starter codebase and the feature specifications you are asked to implement.

---

## Where to find the features to implement

All feature specifications are in the **`Features`** folder at the root of this repo. Each feature is described in a PDF:

| File | Description |
|------|-------------|
| **Feature 1 - Idempotent subscription creation.pdf** | Idempotent subscription creation |
| **Feature 2 - Subscription state transitions (cancel, reactivate).pdf** | Subscription state transitions (cancel, reactivate) |
| **Feature 3 - Webhook event ingestion for payments.pdf** | Webhook event ingestion for payments |

Read these documents for requirements, acceptance criteria, and any constraints. Implement the features in the provided **MiniStripe** .NET solution (see below).

---

## Repository structure

- **`Features/`** – PDF specifications for the features to implement (start here).
- **`dotNET/`** – .NET solution and projects, including the MiniStripe API.
- **`Java/`** – Java projects (if applicable).

---

## Feature 1: Idempotent Subscription Creation

### How clients should retry

Include an `Idempotency-Key` HTTP header with a unique value (UUID recommended) on `POST /subscriptions` requests:

```http
POST /subscriptions
Content-Type: application/json
Idempotency-Key: 550e8400-e29b-41d4-a716-446655440000

{ "customerId": "...", "planId": "..." }
```

- Use the **same key** for retries of the same logical operation.
- If the key is omitted, the request is processed normally without deduplication.
- If the same key is reused with a **different request body**, the API returns `409 Conflict`.

### What data is stored

Each idempotency key is persisted in the database (`IdempotencyRecords` table) with:

| Field | Description |
|-------|-------------|
| `IdempotencyKey` | The client-provided unique key (unique index) |
| `RequestHash` | SHA256 hash of `{customerId}:{planId}` — used to detect payload mismatches |
| `ResponseStatusCode` | The HTTP status code of the original response (e.g. `201`) |
| `ResponseBody` | The JSON-serialized response body from the original request |
| `CreatedAt` | Timestamp when the record was created |
| `ExpiresAt` | Timestamp after which the record is eligible for cleanup |

The subscription and idempotency record are saved in a **single database transaction** to prevent orphaned states.

### Limitations

- **Expiration**: Idempotency keys expire after **24 hours**. After expiration, reusing the same key will create a new subscription.
- **Cleanup**: A `BackgroundService` runs every **1 hour** to delete expired records from the database.
- **Scope**: Idempotency is only supported on `POST /subscriptions`. Other endpoints are not covered.
- **Failed requests**: Only successful (`201 Created`) responses are cached. If the original request fails (e.g. customer not found), no idempotency record is stored, allowing the client to retry with corrected data.
- **Max key length**: 256 characters. Longer keys are rejected with `400 Bad Request`.

---

## Feature 2: Subscription State Transitions

### Endpoints
- `POST /subscriptions/{id}/cancel` — Cancel an active or past-due subscription
- `POST /subscriptions/{id}/reactivate` — Reactivate a recently canceled subscription

### State Rules
All transition rules are centralized in `SubscriptionStateMachine`:

| From | To | Condition |
|------|----|-----------|
| Active | Canceled | Always allowed |
| PastDue | Canceled | Always allowed |
| Canceled | Active | Within 30 days of `EndDate` |

### Idempotency
- Canceling an already-canceled subscription returns `200 OK` (no-op).

### Reactivation Window
- A canceled subscription can be reactivated within **30 days** of its `EndDate`.
- After 30 days, reactivation returns `422 Unprocessable Entity` with a clear message.

### Concurrency Handling
- Each subscription has an integer `Version` column used as an optimistic concurrency token.
- If two concurrent requests try to modify the same subscription, the second one receives
  `409 Conflict` with the message: "The subscription was modified by another request. Please retry."
- **Client strategy**: On `409`, re-read the subscription via `GET /subscriptions/{id}` and
  decide whether to retry based on the current state.

### Audit Trail
- Every state transition creates a `SubscriptionAuditRecord` with `FromStatus`, `ToStatus`,
  `Action`, and `OccurredAt`.
- Idempotent no-ops (e.g., canceling an already-canceled subscription) do NOT create audit records.

### Extending the State Machine
To add a new transition (e.g., `Active → PastDue` for payment failures):
1. Add one entry to the `Transitions` dictionary in `SubscriptionStateMachine`.
2. Add a `case` in `Subscription.TransitionTo` for any side-effects.
3. Add the corresponding service method and controller action.


