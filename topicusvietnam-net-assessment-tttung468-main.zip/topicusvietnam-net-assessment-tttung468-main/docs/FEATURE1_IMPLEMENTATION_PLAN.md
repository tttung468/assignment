# Feature 1 — Implementation Plan: Safe Retry for Subscription Creation

## Overview

Add idempotency key support to `POST /subscriptions` so clients can safely retry without creating duplicate subscriptions. Uses database-persisted records, SHA256 payload hashing, and a `BackgroundService` for cleanup.

---

## Steps

### Step 1: Create `IdempotencyRecord` Entity (Domain Layer)

**File**: `MiniStripe.Domain/Idempotency/IdempotencyRecord.cs`

```csharp
public class IdempotencyRecord
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public string IdempotencyKey { get; set; } = default!;
    public string RequestHash { get; set; } = default!;       // SHA256 of request body
    public int ResponseStatusCode { get; set; }
    public string ResponseBody { get; set; } = default!;      // JSON-serialized response
    public DateTimeOffset CreatedAt { get; set; } = DateTimeOffset.UtcNow;
    public DateTimeOffset ExpiresAt { get; set; }
}
```

---

### Step 2: Update `AppDbContext` (Infrastructure Layer)

**File**: `MiniStripe.Infrastructure/Persistence/AppDbContext.cs`

- Add `DbSet<IdempotencyRecord>`
- Add unique index on `IdempotencyKey` in `OnModelCreating`

---

### Step 3: Create EF Core Migration

```bash
cd dotNET/MiniStripe
dotnet ef migrations add AddIdempotencyRecord --project MiniStripe.Infrastructure --startup-project MiniStripe
```

---

### Step 4: Create `IdempotencyService` (Application Layer)

**File**: `MiniStripe.Application/Services/IdempotencyService.cs`

**Methods**:

| Method | Input | Output | Description |
|--------|-------|--------|-------------|
| `TryGetExistingAsync` | `string key, string requestHash, CancellationToken` | `(int statusCode, string body)?` or throws | Looks up key; if found and hash matches, returns cached response; if hash mismatches, throws (409) |
| `StoreAsync` | `string key, string requestHash, int statusCode, string responseBody, CancellationToken` | `void` | Saves record with `ExpiresAt = UtcNow + 24h` |
| `ComputeHash` | `Guid customerId, Guid planId` | `string` | SHA256 of `"{customerId}:{planId}"` |

**Key logic**:
- Ignore expired records during lookup (`ExpiresAt > UtcNow`)
- Hash mismatch → throw a custom exception (handled as 409 in controller)

---

### Step 5: Update `SubscriptionsController` (API Layer)

**File**: `MiniStripe/Controllers/SubscriptionsController.cs`

**Changes to `Create` action**:

```
1. Read "Idempotency-Key" header
2. If absent or empty → proceed normally (no dedup)
3. If present:
   a. Validate (non-whitespace, max 256 chars) → 400 if invalid
   b. Compute request hash from body
   c. Call IdempotencyService.TryGetExistingAsync
      - If cached response found → return it (201 + original body)
      - If hash mismatch → return 409 Conflict
   d. Create subscription via SubscriptionService.CreateAsync
   e. Save idempotency record + subscription in SAME SaveChangesAsync (single transaction)
   f. Return 201
4. Handle DbUpdateException on unique index (concurrent retry):
   - Re-read stored record, return cached response
```

---

### Step 6: Ensure Atomicity (Transaction)

**File**: `MiniStripe.Application/Services/SubscriptionService.cs`

Modify `CreateAsync` to accept an optional `idempotencyKey` + `requestHash` so that both the `Subscription` and `IdempotencyRecord` are saved in the same `SaveChangesAsync` call.

Alternatively, handle this at the controller level by adding the `IdempotencyRecord` to the `DbContext` before calling `SaveChangesAsync`.

**Chosen approach**: Keep `SubscriptionService.CreateAsync` unchanged. In the controller, after creating the subscription, add the `IdempotencyRecord` to the context and rely on the fact that `SaveChangesAsync` in `SubscriptionService` already persists everything in one transaction. **OR** refactor `CreateAsync` to not call `SaveChangesAsync` and let the controller handle it.

**Decision**: Refactor `CreateAsync` to accept an optional `IdempotencyRecord` parameter. If provided, add it to context before `SaveChangesAsync` → single atomic save.

---

### Step 7: Create `IdempotencyCleanupService` (Infrastructure Layer)

**File**: `MiniStripe.Infrastructure/Services/IdempotencyCleanupService.cs`

```csharp
public class IdempotencyCleanupService : BackgroundService
{
    // Interval: every 1 hour
    // Logic: DELETE FROM IdempotencyRecords WHERE ExpiresAt < UtcNow
    // Uses ExecuteDeleteAsync for bulk delete (EF Core 7+)
}
```

---

### Step 8: Register Services in `Program.cs`

**File**: `MiniStripe/Program.cs`

```csharp
builder.Services.AddScoped<IdempotencyService>();
builder.Services.AddHostedService<IdempotencyCleanupService>();
```

---

### Step 9: Create Test Project

**New project**: `MiniStripe.Tests`

```bash
cd dotNET/MiniStripe
dotnet new xunit -n MiniStripe.Tests
dotnet sln MiniStripe.slnx add MiniStripe.Tests/MiniStripe.Tests.csproj
```

**NuGet packages**:
- `xunit` (included by template)
- `Microsoft.NET.Test.Sdk` (included by template)
- `Microsoft.AspNetCore.Mvc.Testing` — for integration tests with `WebApplicationFactory`
- `Microsoft.EntityFrameworkCore.InMemory` or `Microsoft.EntityFrameworkCore.Sqlite` — for in-memory DB in tests
- `FluentAssertions` (optional, for readable assertions)

**Project references**:
- `MiniStripe` (API project)
- `MiniStripe.Application`
- `MiniStripe.Domain`
- `MiniStripe.Infrastructure`
- `MiniStripe.Contracts`

---

### Step 10: Write Unit Tests

#### 10a. `IdempotencyServiceTests` (Application Layer Tests)

| # | Test Name | Description |
|---|-----------|-------------|
| 1 | `TryGetExisting_NoRecord_ReturnsNull` | Key not in DB → returns null |
| 2 | `TryGetExisting_ValidRecord_SameHash_ReturnsCachedResponse` | Key exists, hash matches → returns stored response |
| 3 | `TryGetExisting_ValidRecord_DifferentHash_ThrowsConflict` | Key exists, hash differs → throws exception |
| 4 | `TryGetExisting_ExpiredRecord_ReturnsNull` | Key exists but `ExpiresAt < UtcNow` → returns null (treated as new) |
| 5 | `Store_SavesRecordWithCorrectExpiry` | Saves record, verify `ExpiresAt` is ~24h from now |
| 6 | `ComputeHash_SameInput_SameOutput` | Deterministic hashing |
| 7 | `ComputeHash_DifferentInput_DifferentOutput` | Different payloads produce different hashes |

#### 10b. `SubscriptionServiceTests` (Application Layer Tests)

| # | Test Name | Description |
|---|-----------|-------------|
| 1 | `CreateAsync_ValidInput_CreatesSubscription` | Happy path |
| 2 | `CreateAsync_CustomerNotFound_Throws` | Invalid customer ID |
| 3 | `CreateAsync_PlanNotFound_Throws` | Invalid plan ID |

#### 10c. `IdempotencyCleanupServiceTests` (Infrastructure Tests)

| # | Test Name | Description |
|---|-----------|-------------|
| 1 | `Cleanup_DeletesExpiredRecords` | Seed expired records → run cleanup → verify deleted |
| 2 | `Cleanup_KeepsNonExpiredRecords` | Seed valid records → run cleanup → verify still present |

---

### Step 11: Write Integration Tests

#### 11a. `SubscriptionsControllerIntegrationTests`

Uses `WebApplicationFactory<Program>` with SQLite in-memory for full HTTP pipeline testing.

| # | Test Name | Description |
|---|-----------|-------------|
| 1 | `Post_NoIdempotencyKey_CreatesSubscription` | Normal creation without header |
| 2 | `Post_WithIdempotencyKey_FirstCall_CreatesSubscription` | Returns 201, subscription saved |
| 3 | `Post_WithIdempotencyKey_Retry_SamePayload_ReturnsCachedResponse` | Same key + same body → 201 with original response, no duplicate in DB |
| 4 | `Post_WithIdempotencyKey_Retry_DifferentPayload_Returns409` | Same key + different body → 409 Conflict |
| 5 | `Post_WithEmptyIdempotencyKey_Returns400` | Whitespace/empty key → 400 Bad Request |
| 6 | `Post_WithTooLongIdempotencyKey_Returns400` | Key > 256 chars → 400 Bad Request |
| 7 | `Post_WithIdempotencyKey_CustomerNotFound_Returns404_NotCached` | Failed request → 404, retrying same key with corrected payload should work |
| 8 | `Post_WithIdempotencyKey_PlanNotFound_Returns404_NotCached` | Same as above for plan |
| 9 | `Post_ConcurrentRetries_SameKey_OnlyOneCreated` | Two parallel requests with same key → only one subscription in DB |
| 10 | `Post_ExpiredKey_Reuse_CreatesNewSubscription` | Key used, TTL expires, same key again → new subscription created |

---

### Step 12: Update README

**File**: `README.md`

Add a section:

```markdown
## Idempotent Subscription Creation

### How clients should retry
- Include an `Idempotency-Key` header with a unique value (UUID recommended)
- Use the same key for retries of the same logical operation

### What data is stored
- Idempotency key, SHA256 hash of request payload, HTTP status code, 
  response body, creation timestamp, expiration timestamp

### Limitations
- Keys expire after 24 hours
- Expired keys are cleaned up by a background job every 1 hour
- After expiration, reusing the same key creates a new subscription
- Idempotency is scoped to POST /subscriptions only
```

---

## File Summary

| # | File | Action | Layer |
|---|------|--------|-------|
| 1 | `MiniStripe.Domain/Idempotency/IdempotencyRecord.cs` | **Create** | Domain |
| 2 | `MiniStripe.Infrastructure/Persistence/AppDbContext.cs` | **Edit** | Infrastructure |
| 3 | `MiniStripe.Infrastructure/Migrations/...AddIdempotencyRecord.cs` | **Generate** | Infrastructure |
| 4 | `MiniStripe.Application/Services/IdempotencyService.cs` | **Create** | Application |
| 5 | `MiniStripe/Controllers/SubscriptionsController.cs` | **Edit** | API |
| 6 | `MiniStripe.Application/Services/SubscriptionService.cs` | **Edit** | Application |
| 7 | `MiniStripe.Infrastructure/Services/IdempotencyCleanupService.cs` | **Create** | Infrastructure |
| 8 | `MiniStripe/Program.cs` | **Edit** | API |
| 9 | `MiniStripe.Tests/MiniStripe.Tests.csproj` | **Create** | Tests |
| 10 | `MiniStripe.Tests/Unit/IdempotencyServiceTests.cs` | **Create** | Tests |
| 11 | `MiniStripe.Tests/Unit/SubscriptionServiceTests.cs` | **Create** | Tests |
| 12 | `MiniStripe.Tests/Unit/IdempotencyCleanupServiceTests.cs` | **Create** | Tests |
| 13 | `MiniStripe.Tests/Integration/SubscriptionsControllerTests.cs` | **Create** | Tests |
| 14 | `README.md` | **Edit** | Docs |

---

## Edge Cases Covered

| # | Edge Case | Handling |
|---|-----------|----------|
| 1 | No header | Normal flow, no dedup |
| 2 | Retry same key + same body | Return cached 201 |
| 3 | Same key + different body | 409 Conflict |
| 4 | Empty/whitespace key | 400 Bad Request |
| 5 | Key > 256 chars | 400 Bad Request |
| 6 | Concurrent same-key requests | Unique index + catch DbUpdateException |
| 7 | Failed request (404) | Not cached → client can retry |
| 8 | Expired key reused | Treated as new request |
| 9 | Server restart | Records persist in SQLite |
| 10 | Atomicity | Subscription + IdempotencyRecord saved in single transaction |

---

## Configuration

| Parameter | Value | Rationale |
|-----------|-------|-----------|
| Header name | `Idempotency-Key` | Industry standard (Stripe) |
| TTL | 24 hours | Enough for retries, prevents unbounded growth |
| Cleanup interval | 1 hour | Balances DB size vs. overhead |
| Max key length | 256 characters | Prevents abuse |
| Hash algorithm | SHA256 | Fast, collision-resistant |
| Database | SQLite (same as app) | Survives restarts, no extra infra |
