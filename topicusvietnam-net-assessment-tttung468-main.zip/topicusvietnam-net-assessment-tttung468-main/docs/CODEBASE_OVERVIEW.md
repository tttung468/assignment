﻿# MiniStripe — Codebase Overview

A simplified Stripe-like subscription management API built with .NET and Clean Architecture.

---

## Architecture

The solution follows **Clean Architecture** with 4 layers:

```
MiniStripe (API)  →  MiniStripe.Application  →  MiniStripe.Domain
                            ↓
                  MiniStripe.Infrastructure
```

| Project | Responsibility |
|---------|---------------|
| **MiniStripe** | ASP.NET Core Web API — Controllers, `Program.cs`, config |
| **MiniStripe.Application** | Business logic / services |
| **MiniStripe.Domain** | Entities, enums, core domain models |
| **MiniStripe.Infrastructure** | EF Core `DbContext`, migrations, persistence |
| **MiniStripe.Contracts** | Request/Response DTOs (shared between API and client) |

---

## Domain Models

### Customer
| Property | Type | Notes |
|----------|------|-------|
| `Id` | `Guid` | Auto-generated |
| `Email` | `string` | Unique index |
| `Name` | `string` | |
| `CreatedAt` | `DateTimeOffset` | UTC |

### Plan
| Property | Type | Notes |
|----------|------|-------|
| `Id` | `Guid` | Auto-generated |
| `Code` | `string` | Unique index (e.g. `"starter-monthly"`) |
| `Name` | `string` | |
| `Price` | `decimal` | |
| `Currency` | `string` | Default: `"EUR"` |
| `Interval` | `string` | `"month"` or `"year"` |
| `CreatedAt` | `DateTimeOffset` | UTC |

### Subscription
| Property | Type | Notes |
|----------|------|-------|
| `Id` | `Guid` | Auto-generated |
| `CustomerId` | `Guid` | FK to Customer |
| `PlanId` | `Guid` | FK to Plan |
| `Status` | `SubscriptionStatus` | `Active(0)`, `PastDue(1)`, `Canceled(2)` |
| `StartDate` | `DateTimeOffset` | UTC |
| `EndDate` | `DateTimeOffset?` | Nullable |

### SubscriptionStatus (Enum)
- `Active = 0`
- `PastDue = 1`
- `Canceled = 2`

---

## API Endpoints

### Customers (`/customers`)
| Method | Route | Description |
|--------|-------|-------------|
| `POST` | `/customers` | Create a customer (email must be unique) |
| `GET` | `/customers/{id}` | Get customer by ID |

### Plans (`/plans`)
| Method | Route | Description |
|--------|-------|-------------|
| `POST` | `/plans` | Create a plan (code must be unique) |
| `GET` | `/plans` | List all plans |
| `GET` | `/plans/{id}` | Get plan by ID |

### Subscriptions (`/subscriptions`)
| Method | Route | Description |
|--------|-------|-------------|
| `POST` | `/subscriptions` | Create a subscription (requires valid `CustomerId` + `PlanId`) |
| `GET` | `/subscriptions/{id}` | Get subscription by ID |

---

## Database

- **Engine**: SQLite (`ministripe.db`)
- **ORM**: Entity Framework Core
- **Migrations**: Auto-applied on startup via `db.Database.Migrate()`
- **Connection string**: Configured in `appsettings.json` under `ConnectionStrings:db`

### Indexes
- `Customer.Email` — unique
- `Plan.Code` — unique
- `Subscription(CustomerId, PlanId, Status)` — composite

---

## Key Files

| File | Purpose |
|------|---------|
| `MiniStripe/Program.cs` | App startup, DI registration, middleware |
| `MiniStripe/Controllers/*.cs` | API endpoint handlers |
| `MiniStripe.Application/Services/SubscriptionService.cs` | Subscription creation business logic |
| `MiniStripe.Domain/Subscriptions/Subscription.cs` | Subscription entity |
| `MiniStripe.Domain/Subscriptions/SubscriptionStatus.cs` | Status enum |
| `MiniStripe.Infrastructure/Persistence/AppDbContext.cs` | EF Core context + model config |
| `MiniStripe.Infrastructure/Migrations/` | Database migration files |
| `MiniStripe.Contracts/` | Request/Response record types |

---

## Running the Project

```bash
cd dotNET/MiniStripe
dotnet build
dotnet run --project MiniStripe
```

Swagger UI available at: `http://localhost:<port>/swagger`

---

## Features to Implement

See the `Features/` folder for PDF specifications:

1. **Idempotent subscription creation** — Prevent duplicate subscriptions on retried requests
2. **Subscription state transitions** — Cancel and reactivate subscriptions with proper state machine rules
3. **Webhook event ingestion for payments** — Receive external payment events and update subscription status

---

## Unit Testing Guidelines

Tests live in **MiniStripe.Tests** and are organized into:

| Folder | Scope |
|--------|-------|
| `Unit/` | Tests individual services using an in-memory SQLite database |
| `Integration/` | Tests the full HTTP pipeline via `WebApplicationFactory` |
| `Helpers/` | Shared utilities (e.g. `TestDbContextFactory`) |

### Arrange-Act-Assert (AAA) Pattern

Every test method **must** follow the AAA structure with explicit comments:

```csharp
[Fact]
public async Task MethodName_Scenario_ExpectedResult()
{
    // Arrange — set up test data and dependencies
    var (customer, plan) = await SeedCustomerAndPlanAsync();

    // Act — call the method under test
    var result = await _sut.CreateAsync(customer.Id, plan.Id, ct);

    // Assert — verify the outcome
    result.Status.Should().Be(SubscriptionStatus.Active);
}
```

### Helper Methods

To reduce duplication, each test class defines **private helper methods** for common setup:

| Helper | Class | Purpose |
|--------|-------|---------|
| `SeedCustomerAndPlanAsync()` | `SubscriptionServiceTests` | Seeds a `Customer` + `Plan` and returns both |
| `SeedRecordAsync(key, hash, expiresInHours, ...)` | `IdempotencyServiceTests` | Seeds an `IdempotencyRecord` with configurable expiry |
| `SeedRecord(key, expiresInHours)` | `IdempotencyCleanupServiceTests` | Seeds an `IdempotencyRecord` (synchronous add, caller saves) |

### Rules

1. **Test the real code path** — don't duplicate production logic in tests. If a service method exists, call it.
2. **Fix the source, not just the test** — if production code is untestable (e.g. logic buried in a `protected` method), extract it into a public/static method first.
3. **One concept per test** — each `[Fact]` tests exactly one behavior.
4. **Descriptive names** — use the `MethodName_Scenario_ExpectedResult` naming convention.
