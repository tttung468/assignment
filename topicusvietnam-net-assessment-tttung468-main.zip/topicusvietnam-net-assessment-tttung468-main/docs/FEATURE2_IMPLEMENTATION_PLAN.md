# Feature 2 — Implementation Plan: Subscription State Transitions (Cancel, Reactivate)

## Overview

Add `POST /subscriptions/{id}/cancel` and `POST /subscriptions/{id}/reactivate` endpoints with a **centralized state machine** (`SubscriptionStateMachine`) that holds all transition rules in one place. Uses optimistic concurrency (`Version` column) to detect conflicting updates, and records an audit trail for every transition.

---

## Design Decisions

| Decision | Choice | Rationale |
|----------|--------|-----------|
| State rule location | `SubscriptionStateMachine` — static class with a dictionary-based transition table | Single place to add/modify/remove rules; Feature 3 (webhooks) can add `Active → PastDue` with one line |
| Transition guards | `Func<Subscription, (bool, string?)>` predicates per entry | Allows per-transition business rules (e.g. 30-day reactivation window) without sub-classing |
| Concurrency | Integer `Version` + `.IsConcurrencyToken()` | SQLite has no native `rowversion`; integer token is simple, EF Core auto-checks it in `WHERE` clause |
| Cancel idempotency | Calling cancel on an already-canceled subscription is a no-op returning `200 OK` | Matches spec requirement #3 |
| Reactivation window | 30 days from `EndDate` | Documented business rule, enforced as a guard predicate |
| Invalid transition HTTP code | `422 Unprocessable Entity` | Request is syntactically valid but violates business rules |
| Concurrency conflict HTTP code | `409 Conflict` | Spec requirement for concurrent state-changing requests |
| Audit trail | `SubscriptionAuditRecord` table (bonus) | Cleaner than reusing `IdempotencyRecord`; queryable history of all status changes |

---

## State Machine

```
         ┌──────────┐
    ┌────│  Active   │────┐
    │    └──────────┘    │
    │         ▲          │ cancel
    │         │          ▼
    │   reactivate  ┌──────────┐
    │   (≤30 days)  │ Canceled │
    │         │     └──────────┘
    │         │          ▲
    │    ┌──────────┐    │ cancel
    └────│ PastDue  │────┘
         └──────────┘
```

### Transition Table

| From | To | Guard | Action Side-Effects |
|------|----|-------|---------------------|
| `Active` | `Canceled` | none | `EndDate = UtcNow` |
| `PastDue` | `Canceled` | none | `EndDate = UtcNow` |
| `Canceled` | `Active` | `EndDate` within 30 days of now | `EndDate = null` |

> **Extending later**: To add `Active → PastDue` (Feature 3, payment failure), add one entry to the dictionary in `SubscriptionStateMachine` and handle the new action in the service. No changes to entity, controller, or existing tests.

---

## Steps

### Step 1: Create `SubscriptionStateMachine` (Domain Layer)

**File**: `MiniStripe.Domain/Subscriptions/SubscriptionStateMachine.cs`

Central, static class that owns all transition rules.

```csharp
namespace MiniStripe.Domain.Subscriptions
{
    public static class SubscriptionStateMachine
    {
        public const int ReactivationWindowDays = 30;

        // Transition table: (From, To) → optional guard returning (allowed, reason)
        private static readonly Dictionary<(SubscriptionStatus From, SubscriptionStatus To),
            Func<Subscription, (bool Allowed, string? Reason)>?> Transitions = new()
        {
            [(SubscriptionStatus.Active, SubscriptionStatus.Canceled)] = null, // always allowed
            [(SubscriptionStatus.PastDue, SubscriptionStatus.Canceled)] = null, // always allowed
            [(SubscriptionStatus.Canceled, SubscriptionStatus.Active)] = sub =>
            {
                if (!sub.EndDate.HasValue)
                    return (false, "Subscription has no cancellation date recorded.");

                var daysSinceCanceled = (DateTimeOffset.UtcNow - sub.EndDate.Value).TotalDays;
                return daysSinceCanceled <= ReactivationWindowDays
                    ? (true, null)
                    : (false, $"Subscription was canceled more than {ReactivationWindowDays} days ago "
                            + $"(canceled on {sub.EndDate.Value:O}). Reactivation is no longer allowed.");
            }
        };

        /// <summary>
        /// Check whether a transition is allowed for the given subscription.
        /// Returns (true, null) if allowed, (false, reason) if not.
        /// </summary>
        public static (bool Allowed, string? Reason) CanTransition(
            Subscription subscription, SubscriptionStatus to)
        {
            var key = (subscription.Status, to);

            if (!Transitions.TryGetValue(key, out var guard))
                return (false, $"Transition from {subscription.Status} to {to} is not allowed.");

            if (guard is null)
                return (true, null); // no guard → always allowed

            return guard(subscription);
        }

        /// <summary>
        /// Returns all target statuses reachable from the given status.
        /// Useful for documentation / API discoverability.
        /// </summary>
        public static IReadOnlyList<SubscriptionStatus> GetAllowedTargets(SubscriptionStatus from)
        {
            return Transitions.Keys
                .Where(k => k.From == from)
                .Select(k => k.To)
                .ToList();
        }
    }
}
```

---

### Step 2: Add `Version` and `TransitionTo` to `Subscription` Entity (Domain Layer)

**File**: `MiniStripe.Domain/Subscriptions/Subscription.cs`

```csharp
namespace MiniStripe.Domain.Subscriptions
{
    public class Subscription
    {
        public Guid Id { get; set; } = Guid.NewGuid();
        public Guid CustomerId { get; set; }
        public Guid PlanId { get; set; }
        public SubscriptionStatus Status { get; set; } = SubscriptionStatus.Active;
        public DateTimeOffset StartDate { get; set; } = DateTimeOffset.UtcNow;
        public DateTimeOffset? EndDate { get; set; }

        /// <summary>
        /// Optimistic concurrency token. Incremented on every state change.
        /// EF Core includes this in the WHERE clause of UPDATE statements
        /// to detect conflicting concurrent writes.
        /// </summary>
        public int Version { get; set; }

        /// <summary>
        /// Transitions the subscription to a new status using the centralized
        /// state machine rules. Throws InvalidOperationException if not allowed.
        /// Returns false (no-op) if already in the target status (idempotency).
        /// </summary>
        public bool TransitionTo(SubscriptionStatus newStatus)
        {
            // Idempotent: already in target state
            if (Status == newStatus)
                return false;

            var (allowed, reason) = SubscriptionStateMachine.CanTransition(this, newStatus);
            if (!allowed)
                throw new InvalidOperationException(reason);

            Status = newStatus;
            Version++;

            // Side-effects per target status
            switch (newStatus)
            {
                case SubscriptionStatus.Canceled:
                    EndDate = DateTimeOffset.UtcNow;
                    break;
                case SubscriptionStatus.Active:
                    EndDate = null;
                    break;
            }

            return true;
        }
    }
}
```

**Key points**:
- `TransitionTo` returns `bool` → `false` means no-op (idempotent cancel), `true` means status changed.
- All rule checking delegated to `SubscriptionStateMachine.CanTransition`.
- `Version++` ensures the concurrency token advances on every mutation.

---

### Step 3: Create `SubscriptionAuditRecord` Entity (Domain Layer)

**File**: `MiniStripe.Domain/Subscriptions/SubscriptionAuditRecord.cs`

```csharp
namespace MiniStripe.Domain.Subscriptions
{
    public class SubscriptionAuditRecord
    {
        public Guid Id { get; set; } = Guid.NewGuid();
        public Guid SubscriptionId { get; set; }
        public SubscriptionStatus FromStatus { get; set; }
        public SubscriptionStatus ToStatus { get; set; }
        public string Action { get; set; } = default!;   // "cancel", "reactivate"
        public DateTimeOffset OccurredAt { get; set; } = DateTimeOffset.UtcNow;
    }
}
```

---

### Step 4: Create `ConcurrencyConflictException` (Domain Layer)

**File**: `MiniStripe.Domain/Exceptions/ConcurrencyConflictException.cs`

```csharp
namespace MiniStripe.Domain.Exceptions
{
    public class ConcurrencyConflictException : Exception
    {
        public ConcurrencyConflictException()
            : base("The subscription was modified by another request. Please retry.") { }

        public ConcurrencyConflictException(string message) : base(message) { }

        public ConcurrencyConflictException(string message, Exception inner) : base(message, inner) { }
    }
}
```

---

### Step 5: Update `AppDbContext` (Infrastructure Layer)

**File**: `MiniStripe.Infrastructure/Persistence/AppDbContext.cs`

**Changes**:
1. Add `DbSet<SubscriptionAuditRecord>`.
2. Configure `Subscription.Version` as a concurrency token.
3. Add index on `SubscriptionAuditRecord.SubscriptionId`.

```csharp
// Add to existing using statements
using MiniStripe.Domain.Subscriptions;

// Add new DbSet
public DbSet<SubscriptionAuditRecord> SubscriptionAuditRecords => Set<SubscriptionAuditRecord>();

// Add to OnModelCreating:
modelBuilder.Entity<Subscription>()
    .Property(x => x.Version)
    .IsConcurrencyToken();

modelBuilder.Entity<SubscriptionAuditRecord>()
    .HasIndex(x => x.SubscriptionId);
```

---

### Step 6: Create EF Core Migration

```bash
cd dotNET/MiniStripe
dotnet ef migrations add AddSubscriptionVersionAndAudit \
    --project MiniStripe.Infrastructure \
    --startup-project MiniStripe
```

This generates a migration that:
- Adds `Version` column (`INTEGER`, default `0`) to `Subscriptions` table.
- Creates `SubscriptionAuditRecords` table with columns: `Id`, `SubscriptionId`, `FromStatus`, `ToStatus`, `Action`, `OccurredAt`.
- Adds index on `SubscriptionAuditRecords.SubscriptionId`.

---

### Step 7: Add `CancelAsync` and `ReactivateAsync` to `SubscriptionService` (Application Layer)

**File**: `MiniStripe.Application/Services/SubscriptionService.cs`

```csharp
/// <summary>
/// Cancels a subscription. Idempotent: canceling an already-canceled subscription is a no-op.
/// </summary>
public async Task<Subscription> CancelAsync(Guid subscriptionId, CancellationToken ct)
{
    var sub = await _db.Subscriptions.FindAsync([subscriptionId], ct)
        ?? throw new KeyNotFoundException("Subscription not found.");

    var fromStatus = sub.Status;
    var changed = sub.TransitionTo(SubscriptionStatus.Canceled);

    if (changed)
    {
        _db.SubscriptionAuditRecords.Add(new SubscriptionAuditRecord
        {
            SubscriptionId = sub.Id,
            FromStatus = fromStatus,
            ToStatus = SubscriptionStatus.Canceled,
            Action = "cancel"
        });

        try
        {
            await _db.SaveChangesAsync(ct);
        }
        catch (DbUpdateConcurrencyException ex)
        {
            throw new ConcurrencyConflictException(
                "The subscription was modified by another request. Please retry.", ex);
        }
    }

    return sub;
}

/// <summary>
/// Reactivates a canceled subscription. Only allowed within 30 days of EndDate.
/// </summary>
public async Task<Subscription> ReactivateAsync(Guid subscriptionId, CancellationToken ct)
{
    var sub = await _db.Subscriptions.FindAsync([subscriptionId], ct)
        ?? throw new KeyNotFoundException("Subscription not found.");

    var fromStatus = sub.Status;
    sub.TransitionTo(SubscriptionStatus.Active); // throws if rule violated

    _db.SubscriptionAuditRecords.Add(new SubscriptionAuditRecord
    {
        SubscriptionId = sub.Id,
        FromStatus = fromStatus,
        ToStatus = SubscriptionStatus.Active,
        Action = "reactivate"
    });

    try
    {
        await _db.SaveChangesAsync(ct);
    }
    catch (DbUpdateConcurrencyException ex)
    {
        throw new ConcurrencyConflictException(
            "The subscription was modified by another request. Please retry.", ex);
    }

    return sub;
}
```

**Key points**:
- `CancelAsync` uses `TransitionTo` return value: `false` = already canceled → skip audit + save (idempotent).
- `ReactivateAsync` always expects a real transition; `TransitionTo` throws if invalid.
- Both catch `DbUpdateConcurrencyException` (EF Core detects `Version` mismatch) and wrap it in `ConcurrencyConflictException`.

---

### Step 8: Add Controller Actions (API Layer)

**File**: `MiniStripe/Controllers/SubscriptionsController.cs`

```csharp
[HttpPost("{id:guid}/cancel")]
public async Task<ActionResult<SubscriptionResponse>> Cancel(
    [FromRoute] Guid id, CancellationToken ct)
{
    try
    {
        var sub = await _svc.CancelAsync(id, ct);
        return Ok(new SubscriptionResponse(
            sub.Id, sub.CustomerId, sub.PlanId, sub.Status, sub.StartDate, sub.EndDate));
    }
    catch (KeyNotFoundException)
    {
        return NotFound();
    }
    catch (InvalidOperationException ex)
    {
        return UnprocessableEntity(ex.Message);
    }
    catch (ConcurrencyConflictException ex)
    {
        return Conflict(ex.Message);
    }
}

[HttpPost("{id:guid}/reactivate")]
public async Task<ActionResult<SubscriptionResponse>> Reactivate(
    [FromRoute] Guid id, CancellationToken ct)
{
    try
    {
        var sub = await _svc.ReactivateAsync(id, ct);
        return Ok(new SubscriptionResponse(
            sub.Id, sub.CustomerId, sub.PlanId, sub.Status, sub.StartDate, sub.EndDate));
    }
    catch (KeyNotFoundException)
    {
        return NotFound();
    }
    catch (InvalidOperationException ex)
    {
        return UnprocessableEntity(ex.Message);
    }
    catch (ConcurrencyConflictException ex)
    {
        return Conflict(ex.Message);
    }
}
```

**Requires** adding `using MiniStripe.Domain.Exceptions;` at the top.

---

### Step 9: No changes to `Program.cs`

`SubscriptionService` is already registered as `AddScoped<SubscriptionService>()`. The new `CancelAsync` / `ReactivateAsync` methods are on the same class, so no new DI registrations are needed.

---

### Step 10: Write Unit Tests

#### 10a. `SubscriptionStateMachineTests` — rules tested in isolation

**File**: `MiniStripe.Tests/Unit/SubscriptionStateMachineTests.cs`

| # | Test Name | Description |
|---|-----------|-------------|
| 1 | `CanTransition_ActiveToCanceled_ReturnsAllowed` | No guard, always allowed |
| 2 | `CanTransition_PastDueToCanceled_ReturnsAllowed` | No guard, always allowed |
| 3 | `CanTransition_CanceledToActive_Within30Days_ReturnsAllowed` | Guard passes: `EndDate` is recent |
| 4 | `CanTransition_CanceledToActive_After30Days_ReturnsNotAllowedWithReason` | Guard fails: too old |
| 5 | `CanTransition_CanceledToActive_NoEndDate_ReturnsNotAllowed` | Edge: `EndDate` is null |
| 6 | `CanTransition_ActiveToActive_ReturnsNotAllowed` | Not in transition table |
| 7 | `CanTransition_ActiveToPastDue_ReturnsNotAllowed` | Not yet registered (extensibility proof) |
| 8 | `GetAllowedTargets_FromActive_ReturnsCanceled` | Utility method validation |
| 9 | `GetAllowedTargets_FromCanceled_ReturnsActive` | Utility method validation |

#### 10b. `SubscriptionServiceTests` — cancel/reactivate service methods

**File**: `MiniStripe.Tests/Unit/SubscriptionServiceTests.cs` (extend existing)

| # | Test Name | Description |
|---|-----------|-------------|
| 1 | `CancelAsync_ActiveSubscription_SetsCanceledAndEndDate` | Status → Canceled, EndDate set, audit record created |
| 2 | `CancelAsync_PastDueSubscription_SetsCanceled` | Allowed transition |
| 3 | `CancelAsync_AlreadyCanceled_IsIdempotent_NoAuditRecord` | No error, no audit, EndDate unchanged |
| 4 | `CancelAsync_NotFound_ThrowsKeyNotFoundException` | Subscription doesn't exist |
| 5 | `ReactivateAsync_RecentlyCanceled_SetsActiveAndClearsEndDate` | Status → Active, EndDate null, audit created |
| 6 | `ReactivateAsync_CanceledOver30Days_ThrowsInvalidOperation` | Guard rejects, clear message |
| 7 | `ReactivateAsync_ActiveSubscription_ThrowsInvalidOperation` | Invalid: Active → Active not in table |
| 8 | `ReactivateAsync_NotFound_ThrowsKeyNotFoundException` | Subscription doesn't exist |

#### 10c. `SubscriptionDomainTests` — entity `TransitionTo` method

**File**: `MiniStripe.Tests/Unit/SubscriptionDomainTests.cs`

| # | Test Name | Description |
|---|-----------|-------------|
| 1 | `TransitionTo_Canceled_FromActive_ReturnsTrue_SetsEndDate` | Happy path |
| 2 | `TransitionTo_Canceled_FromPastDue_ReturnsTrue` | Allowed |
| 3 | `TransitionTo_Canceled_FromCanceled_ReturnsFalse_NoOp` | Idempotent |
| 4 | `TransitionTo_Active_FromCanceled_Within30Days_ReturnsTrue_ClearsEndDate` | Happy path |
| 5 | `TransitionTo_Active_FromCanceled_After30Days_Throws` | Guard fails |
| 6 | `TransitionTo_Active_FromActive_ReturnsFalse_NoOp` | Same-state idempotency |
| 7 | `TransitionTo_IncrementsVersion` | Version increases by 1 |

---

### Step 11: Write Integration Tests

**File**: `MiniStripe.Tests/Integration/SubscriptionsControllerTests.cs` (extend existing)

| # | Test Name | Description |
|---|-----------|-------------|
| 1 | `Cancel_ActiveSubscription_Returns200_StatusIsCanceled` | Body has Canceled status and EndDate |
| 2 | `Cancel_PastDueSubscription_Returns200` | Allowed transition |
| 3 | `Cancel_AlreadyCanceled_Returns200_Idempotent` | Same state, no error |
| 4 | `Cancel_NonExistent_Returns404` | Subscription not found |
| 5 | `Reactivate_RecentlyCanceled_Returns200_StatusIsActive` | Status back to Active, EndDate null |
| 6 | `Reactivate_CanceledTooLongAgo_Returns422_WithMessage` | Clear rejection message |
| 7 | `Reactivate_ActiveSubscription_Returns422` | Invalid transition |
| 8 | `Reactivate_NonExistent_Returns404` | Subscription not found |

---

### Step 12: Update README

**File**: `README.md`

Add section:

```markdown
## Subscription State Transitions

### Endpoints
- `POST /subscriptions/{id}/cancel` — Cancel an active or past-due subscription
- `POST /subscriptions/{id}/reactivate` — Reactivate a recently canceled subscription

### State Rules
All transition rules are centralized in `SubscriptionStateMachine`:

| From | To | Condition |
|------|----|-----------|
| Active | Canceled | Always allowed |
| PastDue | Canceled | Always allowed |
| Canceled | Active | Within 30 days of `EndDate` |

### Idempotency
- Canceling an already-canceled subscription returns `200 OK` (no-op).

### Reactivation Window
- A canceled subscription can be reactivated within **30 days** of its `EndDate`.
- After 30 days, reactivation returns `422 Unprocessable Entity` with a clear message.

### Concurrency Handling
- Each subscription has an integer `Version` column used as an optimistic concurrency token.
- If two concurrent requests try to modify the same subscription, the second one receives
  `409 Conflict` with the message: "The subscription was modified by another request. Please retry."
- **Client strategy**: On `409`, re-read the subscription via `GET /subscriptions/{id}` and
  decide whether to retry based on the current state.

### Audit Trail
- Every state transition creates a `SubscriptionAuditRecord` with `FromStatus`, `ToStatus`,
  `Action`, and `OccurredAt`.
- Idempotent no-ops (e.g., canceling an already-canceled subscription) do NOT create audit records.

### Extending the State Machine
To add a new transition (e.g., `Active → PastDue` for payment failures):
1. Add one entry to the `Transitions` dictionary in `SubscriptionStateMachine`.
2. Add a `case` in `Subscription.TransitionTo` for any side-effects.
3. Add the corresponding service method and controller action.
```

---

## File Summary

| # | File | Action | Layer |
|---|------|--------|-------|
| 1 | `MiniStripe.Domain/Subscriptions/SubscriptionStateMachine.cs` | **Create** | Domain |
| 2 | `MiniStripe.Domain/Subscriptions/Subscription.cs` | **Edit** | Domain |
| 3 | `MiniStripe.Domain/Subscriptions/SubscriptionAuditRecord.cs` | **Create** | Domain |
| 4 | `MiniStripe.Domain/Exceptions/ConcurrencyConflictException.cs` | **Create** | Domain |
| 5 | `MiniStripe.Infrastructure/Persistence/AppDbContext.cs` | **Edit** | Infrastructure |
| 6 | `MiniStripe.Infrastructure/Migrations/...AddSubscriptionVersionAndAudit.cs` | **Generate** | Infrastructure |
| 7 | `MiniStripe.Application/Services/SubscriptionService.cs` | **Edit** | Application |
| 8 | `MiniStripe/Controllers/SubscriptionsController.cs` | **Edit** | API |
| 9 | `MiniStripe.Tests/Unit/SubscriptionStateMachineTests.cs` | **Create** | Tests |
| 10 | `MiniStripe.Tests/Unit/SubscriptionDomainTests.cs` | **Create** | Tests |
| 11 | `MiniStripe.Tests/Unit/SubscriptionServiceTests.cs` | **Edit** | Tests |
| 12 | `MiniStripe.Tests/Integration/SubscriptionsControllerTests.cs` | **Edit** | Tests |
| 13 | `README.md` | **Edit** | Docs |

---

## Edge Cases Covered

| # | Edge Case | Handling |
|---|-----------|----------|
| 1 | Subscription not found | `404 Not Found` |
| 2 | Cancel an active subscription | `200 OK`, status → Canceled, EndDate set |
| 3 | Cancel a past-due subscription | `200 OK`, status → Canceled, EndDate set |
| 4 | Cancel an already-canceled subscription | `200 OK` (idempotent no-op, EndDate unchanged) |
| 5 | Reactivate within 30 days | `200 OK`, status → Active, EndDate cleared |
| 6 | Reactivate after 30 days | `422 Unprocessable Entity` with clear message |
| 7 | Reactivate an active subscription | `422 Unprocessable Entity` (same-state = no-op via `TransitionTo`, but reactivate implies intent so we could treat Active→Active as no-op; however the domain method returns `false` and service can return `200 OK` — **design choice**: treat as `422` because client likely has stale state) |
| 8 | Reactivate a past-due subscription | `422 Unprocessable Entity` (PastDue → Active not in table) |
| 9 | Concurrent cancel + reactivate | Second request gets `409 Conflict` (Version mismatch) |
| 10 | Concurrent cancel + payment event (Feature 3) | Same `409 Conflict` mechanism applies |
| 11 | Canceled subscription with no EndDate (data repair) | Reactivation guard rejects: "no cancellation date recorded" |

---

## Configuration

| Parameter | Value | Rationale |
|-----------|-------|-----------|
| Reactivation window | 30 days | Reasonable grace period for billing disputes / customer recovery |
| Concurrency mechanism | Integer `Version` + `.IsConcurrencyToken()` | SQLite-compatible; EF Core auto-adds `WHERE Version = @old` |
| Audit storage | `SubscriptionAuditRecords` table | Persist alongside subscription data in same SQLite DB |
| Cancel idempotency | No-op + `200 OK` | Spec requirement #3; simplifies client retry logic |

---

## Verification Checklist

1. `dotnet build` — all projects compile
2. `dotnet ef migrations add ...` — migration generates clean SQL
3. `dotnet test` — all new + existing tests pass
4. Manual via Swagger:
   - Create customer + plan + subscription
   - `POST /subscriptions/{id}/cancel` → `200`, status = Canceled
   - `POST /subscriptions/{id}/cancel` again → `200` (idempotent)
   - `POST /subscriptions/{id}/reactivate` → `200`, status = Active
   - `POST /subscriptions/{id}/reactivate` on active → `422`
   - `GET /subscriptions/{id}` → verify final state
