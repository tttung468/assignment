﻿namespace MiniStripe.Contracts.Customers
{
    public record CreateCustomerRequest(string Email, string Name);
}
