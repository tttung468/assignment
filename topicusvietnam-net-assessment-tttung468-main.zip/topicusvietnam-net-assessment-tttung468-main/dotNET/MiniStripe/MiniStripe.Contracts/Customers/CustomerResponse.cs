﻿namespace MiniStripe.Contracts.Customers
{
    public record CustomerResponse(Guid Id, string Email, string Name, DateTimeOffset CreatedAt);
}
