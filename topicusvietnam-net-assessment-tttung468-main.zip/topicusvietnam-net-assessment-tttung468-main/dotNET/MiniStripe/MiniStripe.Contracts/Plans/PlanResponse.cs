﻿namespace MiniStripe.Contracts.Plans
{
    public record PlanResponse(Guid Id, string Code, string Name, decimal Price, string Currency, string Interval, DateTimeOffset CreatedAt);
}
