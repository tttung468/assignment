﻿namespace MiniStripe.Contracts.Plans
{
    public record CreatePlanRequest(string Code, string Name, decimal Price, string Currency, string Interval);
}
