﻿using MiniStripe.Domain.Subscriptions;

namespace MiniStripe.Contracts.Subscriptions
{
    public record SubscriptionResponse(
        Guid Id,
        Guid CustomerId,
        Guid PlanId,
        SubscriptionStatus Status,
        DateTimeOffset StartDate,
        DateTimeOffset? EndDate
    );
}
