﻿namespace MiniStripe.Contracts.Subscriptions
{
    public record CreateSubscriptionRequest(Guid CustomerId, Guid PlanId);
}
