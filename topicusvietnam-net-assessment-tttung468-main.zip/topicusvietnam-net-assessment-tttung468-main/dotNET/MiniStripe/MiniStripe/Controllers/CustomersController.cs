﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MiniStripe.Contracts.Customers;
using MiniStripe.Domain.Customers;
using MiniStripe.Infrastructure.Persistence;

namespace MiniStripe.Controllers
{
    [ApiController]
    [Route("customers")]
    public class CustomersController : ControllerBase
    {
        private readonly AppDbContext _db;

        public CustomersController(AppDbContext db) => _db = db;

        [HttpPost]
        public async Task<ActionResult<CustomerResponse>> Create([FromBody] CreateCustomerRequest req, CancellationToken ct)
        {
            if (string.IsNullOrWhiteSpace(req.Email))
                return BadRequest("Email is required.");

            var customer = new Customer
            {
                Email = req.Email.Trim(),
                Name = (req.Name ?? "").Trim()
            };

            _db.Customers.Add(customer);

            try
            {
                await _db.SaveChangesAsync(ct);
            }
            catch (DbUpdateException)
            {
                return Conflict("Customer email already exists.");
            }

            var resp = new CustomerResponse(customer.Id, customer.Email, customer.Name, customer.CreatedAt);
            return CreatedAtAction(nameof(GetById), new { id = customer.Id }, resp);
        }

        [HttpGet("{id:guid}")]
        public async Task<ActionResult<CustomerResponse>> GetById([FromRoute] Guid id, CancellationToken ct)
        {
            var customer = await _db.Customers.FindAsync([id], ct);
            if (customer is null) return NotFound();

            return Ok(new CustomerResponse(customer.Id, customer.Email, customer.Name, customer.CreatedAt));
        }
    }
}
