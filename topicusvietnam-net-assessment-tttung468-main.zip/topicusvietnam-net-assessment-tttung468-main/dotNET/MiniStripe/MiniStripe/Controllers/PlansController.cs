﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MiniStripe.Contracts.Plans;
using MiniStripe.Domain.Plans;
using MiniStripe.Infrastructure.Persistence;

namespace MiniStripe.Controllers
{
    [ApiController]
    [Route("plans")]
    public class PlansController : ControllerBase
    {
        private readonly AppDbContext _db;

        public PlansController(AppDbContext db) => _db = db;

        [HttpPost]
        public async Task<ActionResult<PlanResponse>> Create([FromBody] CreatePlanRequest req, CancellationToken ct)
        {
            if (string.IsNullOrWhiteSpace(req.Code))
                return BadRequest("Code is required.");

            var plan = new Plan
            {
                Code = req.Code.Trim(),
                Name = (req.Name ?? "").Trim(),
                Price = req.Price,
                Currency = string.IsNullOrWhiteSpace(req.Currency) ? "EUR" : req.Currency.Trim(),
                Interval = string.IsNullOrWhiteSpace(req.Interval) ? "month" : req.Interval.Trim()
            };

            _db.Plans.Add(plan);

            try
            {
                await _db.SaveChangesAsync(ct);
            }
            catch (DbUpdateException)
            {
                return Conflict("Plan code already exists.");
            }

            var resp = new PlanResponse(plan.Id, plan.Code, plan.Name, plan.Price, plan.Currency, plan.Interval, plan.CreatedAt);
            return CreatedAtAction(nameof(GetById), new { id = plan.Id }, resp);
        }

        [HttpGet]
        public async Task<ActionResult<List<PlanResponse>>> List(CancellationToken ct)
        {
            var plans = await _db.Plans
                .OrderBy(x => x.Code)
                .Select(p => new PlanResponse(p.Id, p.Code, p.Name, p.Price, p.Currency, p.Interval, p.CreatedAt))
                .ToListAsync(ct);

            return Ok(plans);
        }

        [HttpGet("{id:guid}")]
        public async Task<ActionResult<PlanResponse>> GetById([FromRoute] Guid id, CancellationToken ct)
        {
            var plan = await _db.Plans.FindAsync([id], ct);
            if (plan is null) return NotFound();

            return Ok(new PlanResponse(plan.Id, plan.Code, plan.Name, plan.Price, plan.Currency, plan.Interval, plan.CreatedAt));
        }
    }
}
