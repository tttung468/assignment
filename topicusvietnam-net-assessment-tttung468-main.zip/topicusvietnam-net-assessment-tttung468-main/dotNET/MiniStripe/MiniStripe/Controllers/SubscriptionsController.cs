using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MiniStripe.Application.Services;
using MiniStripe.Contracts.Subscriptions;
using MiniStripe.Domain.Exceptions;
using MiniStripe.Infrastructure.Persistence;
using System.Text.Json;

namespace MiniStripe.Controllers
{
    [ApiController]
    [Route("subscriptions")]
    public class SubscriptionsController : ControllerBase
    {
        private readonly AppDbContext _db;
        private readonly SubscriptionService _svc;
        private readonly IdempotencyService _idempotency;

        private const int MaxIdempotencyKeyLength = 256;

        private static readonly JsonSerializerOptions JsonOptions = new()
        {
            PropertyNameCaseInsensitive = true
        };

        public SubscriptionsController(AppDbContext db, SubscriptionService svc, IdempotencyService idempotency)
        {
            _db = db;
            _svc = svc;
            _idempotency = idempotency;
        }

        [HttpPost]
        public async Task<ActionResult<SubscriptionResponse>> Create(
            [FromBody] CreateSubscriptionRequest req, CancellationToken ct)
        {
            var hasKey = Request.Headers.TryGetValue("Idempotency-Key", out var keyValues);
            var idempotencyKey = hasKey ? keyValues.ToString() : null;

            // No idempotency key -> create normally
            if (string.IsNullOrEmpty(idempotencyKey))
            {
                return await CreateWithoutIdempotency(req, ct);
            }

            // Validate key format
            if (string.IsNullOrWhiteSpace(idempotencyKey))
                return BadRequest("Idempotency-Key header must not be empty or whitespace.");

            if (idempotencyKey.Length > MaxIdempotencyKeyLength)
                return BadRequest($"Idempotency-Key must not exceed {MaxIdempotencyKeyLength} characters.");

            var requestHash = IdempotencyService.ComputeHash(req.CustomerId, req.PlanId);

            // Check for existing idempotency record
            try
            {
                var existing = await _idempotency.TryGetExistingAsync(idempotencyKey, requestHash, ct);
                if (existing is not null)
                {
                    var cachedResponse = JsonSerializer.Deserialize<SubscriptionResponse>(
                        existing.Value.Body, JsonOptions);
                    return StatusCode(existing.Value.StatusCode, cachedResponse);
                }
            }
            catch (IdempotencyException ex)
            {
                return Conflict(ex.Message);
            }

            // Create subscription + idempotency record atomically
            return await CreateWithIdempotency(req, ct, idempotencyKey, requestHash);
        }

        private async Task<ActionResult<SubscriptionResponse>> CreateWithoutIdempotency(
            CreateSubscriptionRequest req, CancellationToken ct)
        {
            try
            {
                var sub = await _svc.CreateAsync(req.CustomerId, req.PlanId, ct);
                var resp = new SubscriptionResponse(
                    sub.Id, sub.CustomerId, sub.PlanId, sub.Status, sub.StartDate, sub.EndDate);
                return CreatedAtAction(nameof(GetById), new { id = sub.Id }, resp);
            }
            catch (InvalidOperationException ex)
            {
                return NotFound(ex.Message);
            }
        }

        private async Task<ActionResult<SubscriptionResponse>> CreateWithIdempotency(
            CreateSubscriptionRequest req, CancellationToken ct,
            string idempotencyKey, string requestHash)
        {
            try
            {
                // 1. Prepare subscription (adds to context, does NOT save)
                var sub = await _svc.PrepareAsync(req.CustomerId, req.PlanId, ct);

                // 2. Build the response (sub.Id is already set via Guid.NewGuid())
                var resp = new SubscriptionResponse(
                    sub.Id, sub.CustomerId, sub.PlanId, sub.Status, sub.StartDate, sub.EndDate);

                // 3. Prepare idempotency record with serialized response
                _idempotency.PrepareRecord(
                    idempotencyKey,
                    requestHash,
                    StatusCodes.Status201Created,
                    JsonSerializer.Serialize(resp));

                // 4. Single SaveChangesAsync -> subscription + idempotency record saved atomically
                try
                {
                    await _db.SaveChangesAsync(ct);
                }
                catch (DbUpdateException)
                {
                    // Concurrent request with same key won the unique index race.
                    // Detach tracked entities to avoid stale state.
                    _db.ChangeTracker.Clear();

                    var cached = await _idempotency.TryGetExistingAsync(idempotencyKey, requestHash, ct);
                    if (cached is not null)
                    {
                        var cachedResp = JsonSerializer.Deserialize<SubscriptionResponse>(
                            cached.Value.Body, JsonOptions);
                        return StatusCode(cached.Value.StatusCode, cachedResp);
                    }

                    return Conflict("A concurrent request with the same idempotency key was processed.");
                }

                return CreatedAtAction(nameof(GetById), new { id = sub.Id }, resp);
            }
            catch (InvalidOperationException ex)
            {
                return NotFound(ex.Message);
            }
        }

        [HttpGet("{id:guid}")]
        public async Task<ActionResult<SubscriptionResponse>> GetById([FromRoute] Guid id, CancellationToken ct)
        {
            var sub = await _db.Subscriptions.FindAsync([id], ct);
            if (sub is null) return NotFound();

            return Ok(new SubscriptionResponse(sub.Id, sub.CustomerId, sub.PlanId, sub.Status, sub.StartDate, sub.EndDate));
        }

        [HttpPost("{id:guid}/cancel")]
        public async Task<ActionResult<SubscriptionResponse>> Cancel(
            [FromRoute] Guid id, CancellationToken ct)
        {
            try
            {
                var sub = await _svc.CancelAsync(id, ct);
                return Ok(new SubscriptionResponse(
                    sub.Id, sub.CustomerId, sub.PlanId, sub.Status, sub.StartDate, sub.EndDate));
            }
            catch (KeyNotFoundException)
            {
                return NotFound();
            }
            catch (InvalidOperationException ex)
            {
                return UnprocessableEntity(ex.Message);
            }
            catch (ConcurrencyConflictException ex)
            {
                return Conflict(ex.Message);
            }
        }

        [HttpPost("{id:guid}/reactivate")]
        public async Task<ActionResult<SubscriptionResponse>> Reactivate(
            [FromRoute] Guid id, CancellationToken ct)
        {
            try
            {
                var sub = await _svc.ReactivateAsync(id, ct);
                return Ok(new SubscriptionResponse(
                    sub.Id, sub.CustomerId, sub.PlanId, sub.Status, sub.StartDate, sub.EndDate));
            }
            catch (KeyNotFoundException)
            {
                return NotFound();
            }
            catch (InvalidOperationException ex)
            {
                return UnprocessableEntity(ex.Message);
            }
            catch (ConcurrencyConflictException ex)
            {
                return Conflict(ex.Message);
            }
        }
    }
}
