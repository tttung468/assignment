using Microsoft.EntityFrameworkCore;
using MiniStripe.Application.Services;
using MiniStripe.Infrastructure.Persistence;
using MiniStripe.Infrastructure.Services;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

builder.Services.AddDbContext<AppDbContext>(opt =>
{
    var cs = builder.Configuration.GetConnectionString("db") ?? "Data Source=ministripe.db";
    opt.UseSqlite(cs);
});

builder.Services.AddScoped<SubscriptionService>();
builder.Services.AddScoped<IdempotencyService>();
builder.Services.AddHostedService<IdempotencyCleanupService>();

var app = builder.Build();

app.UseSwagger();
app.UseSwaggerUI();

app.MapControllers();

// For take-home simplicity: auto-apply migrations on startup
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
    db.Database.Migrate();
}

app.Run();

// Make the auto-generated Program class accessible to integration tests
public partial class Program { }