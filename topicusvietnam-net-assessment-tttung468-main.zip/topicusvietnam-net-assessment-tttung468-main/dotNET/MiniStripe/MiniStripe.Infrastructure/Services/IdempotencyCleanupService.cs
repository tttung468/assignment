using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using MiniStripe.Infrastructure.Persistence;

namespace MiniStripe.Infrastructure.Services
{
    public class IdempotencyCleanupService : BackgroundService
    {
        private readonly IServiceScopeFactory _scopeFactory;
        private readonly ILogger<IdempotencyCleanupService> _logger;
        private readonly TimeSpan _interval = TimeSpan.FromHours(1);

        public IdempotencyCleanupService(
            IServiceScopeFactory scopeFactory,
            ILogger<IdempotencyCleanupService> logger)
        {
            _scopeFactory = scopeFactory;
            _logger = logger;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            _logger.LogInformation("IdempotencyCleanupService started. Interval: {Interval}", _interval);

            while (!stoppingToken.IsCancellationRequested)
            {
                await Task.Delay(_interval, stoppingToken);

                try
                {
                    using var scope = _scopeFactory.CreateScope();
                    var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();

                    var deleted = await CleanupExpiredRecordsAsync(db, stoppingToken);

                    if (deleted > 0)
                    {
                        _logger.LogInformation("Cleaned up {Count} expired idempotency records.", deleted);
                    }
                }
                catch (OperationCanceledException) when (stoppingToken.IsCancellationRequested)
                {
                    // Graceful shutdown
                    break;
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Error during idempotency cleanup.");
                }
            }
        }

        /// <summary>
        /// Removes all idempotency records whose ExpiresAt is in the past.
        /// Returns the number of deleted records.
        /// Extracted as a public static method so it can be unit-tested directly.
        /// </summary>
        public static async Task<int> CleanupExpiredRecordsAsync(AppDbContext db, CancellationToken ct = default)
        {
            var cutoff = DateTimeOffset.UtcNow;
            // SQLite can't translate DateTimeOffset comparisons in LINQ,
            // so load all records and filter in memory
            var allRecords = await db.IdempotencyRecords.ToListAsync(ct);
            var expired = allRecords.Where(r => r.ExpiresAt < cutoff).ToList();
            db.IdempotencyRecords.RemoveRange(expired);
            await db.SaveChangesAsync(ct);
            return expired.Count;
        }
    }
}
