﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;

namespace MiniStripe.Infrastructure.Persistence
{
    public sealed class AppDbContextFactory : IDesignTimeDbContextFactory<AppDbContext>
    {
        public AppDbContext CreateDbContext(string[] args)
        {
            var optionsBuilder = new DbContextOptionsBuilder<AppDbContext>();

            // Keep it simple for design-time. Use env var override if you want.
            var cs = Environment.GetEnvironmentVariable("MINISTRIPE_DB")
                     ?? "Data Source=ministripe.db";

            optionsBuilder.UseSqlite(cs);

            return new AppDbContext(optionsBuilder.Options);
        }
    }
}
