﻿using Microsoft.EntityFrameworkCore;
using MiniStripe.Domain.Customers;
using MiniStripe.Domain.Idempotency;
using MiniStripe.Domain.Plans;
using MiniStripe.Domain.Subscriptions;

namespace MiniStripe.Infrastructure.Persistence
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        public DbSet<Customer> Customers => Set<Customer>();
        public DbSet<Plan> Plans => Set<Plan>();
        public DbSet<Subscription> Subscriptions => Set<Subscription>();
        public DbSet<SubscriptionAuditRecord> SubscriptionAuditRecords => Set<SubscriptionAuditRecord>();
        public DbSet<IdempotencyRecord> IdempotencyRecords => Set<IdempotencyRecord>();

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Customer>()
                .HasIndex(x => x.Email)
                .IsUnique();

            modelBuilder.Entity<Plan>()
                .HasIndex(x => x.Code)
                .IsUnique();

            modelBuilder.Entity<Subscription>()
                .HasIndex(x => new { x.CustomerId, x.PlanId, x.Status });

            modelBuilder.Entity<Subscription>()
                .Property(x => x.Version)
                .IsConcurrencyToken();

            modelBuilder.Entity<SubscriptionAuditRecord>()
                .HasIndex(x => x.SubscriptionId);

            modelBuilder.Entity<IdempotencyRecord>()
                .HasIndex(x => x.IdempotencyKey)
                .IsUnique();

            modelBuilder.Entity<IdempotencyRecord>()
                .HasIndex(x => x.ExpiresAt);

            base.OnModelCreating(modelBuilder);
        }
    }
}
