﻿namespace MiniStripe.Domain.Plans
{
    public class Plan
    {
        public Guid Id { get; set; } = Guid.NewGuid();
        public string Code { get; set; } = default!; // e.g. "starter-monthly"
        public string Name { get; set; } = default!;
        public decimal Price { get; set; }
        public string Currency { get; set; } = "EUR";
        public string Interval { get; set; } = "month"; // "month" | "year"
        public DateTimeOffset CreatedAt { get; set; } = DateTimeOffset.UtcNow;
    }
}
