namespace MiniStripe.Domain.Idempotency
{
    public class IdempotencyRecord
    {
        public Guid Id { get; set; } = Guid.NewGuid();
        public string IdempotencyKey { get; set; } = default!;
        public string RequestHash { get; set; } = default!;
        public int ResponseStatusCode { get; set; }
        public string ResponseBody { get; set; } = default!;
        public DateTimeOffset CreatedAt { get; set; } = DateTimeOffset.UtcNow;
        public DateTimeOffset ExpiresAt { get; set; }
    }
}
