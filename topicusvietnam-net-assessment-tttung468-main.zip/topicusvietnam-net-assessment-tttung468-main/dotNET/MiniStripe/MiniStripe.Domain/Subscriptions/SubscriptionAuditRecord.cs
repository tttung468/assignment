namespace MiniStripe.Domain.Subscriptions
{
    /// <summary>
    /// Records every subscription state transition for audit purposes.
    /// </summary>
    public class SubscriptionAuditRecord
    {
        public Guid Id { get; set; } = Guid.NewGuid();
        public Guid SubscriptionId { get; set; }
        public SubscriptionStatus FromStatus { get; set; }
        public SubscriptionStatus ToStatus { get; set; }
        public string Action { get; set; } = default!;   // "cancel", "reactivate"
        public DateTimeOffset OccurredAt { get; set; } = DateTimeOffset.UtcNow;
    }
}
