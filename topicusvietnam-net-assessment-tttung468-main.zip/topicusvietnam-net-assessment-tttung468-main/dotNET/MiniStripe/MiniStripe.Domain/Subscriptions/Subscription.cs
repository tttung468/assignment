﻿namespace MiniStripe.Domain.Subscriptions
{
    public class Subscription
    {
        public Guid Id { get; set; } = Guid.NewGuid();
        public Guid CustomerId { get; set; }
        public Guid PlanId { get; set; }
        public SubscriptionStatus Status { get; set; } = SubscriptionStatus.Active;
        public DateTimeOffset StartDate { get; set; } = DateTimeOffset.UtcNow;
        public DateTimeOffset? EndDate { get; set; }

        /// <summary>
        /// Optimistic concurrency token. Incremented on every state change.
        /// EF Core includes this in the WHERE clause of UPDATE statements
        /// to detect conflicting concurrent writes.
        /// </summary>
        public int Version { get; set; }

        /// <summary>
        /// Transitions the subscription to a new status using the centralized
        /// state machine rules. Throws InvalidOperationException if not allowed.
        /// Returns false (no-op) if already in the target status (idempotency).
        /// </summary>
        public bool TransitionTo(SubscriptionStatus newStatus)
        {
            // Idempotent: already in target state
            if (Status == newStatus)
                return false;

            var (allowed, reason) = SubscriptionStateMachine.CanTransition(this, newStatus);
            if (!allowed)
                throw new InvalidOperationException(reason);

            Status = newStatus;
            Version++;

            // Side-effects per target status
            switch (newStatus)
            {
                case SubscriptionStatus.Canceled:
                    EndDate = DateTimeOffset.UtcNow;
                    break;
                case SubscriptionStatus.Active:
                    EndDate = null;
                    break;
            }

            return true;
        }
    }
}
