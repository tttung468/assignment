namespace MiniStripe.Domain.Subscriptions
{
    /// <summary>
    /// Centralized state machine that owns all subscription transition rules.
    /// To add a new transition (e.g. Active → PastDue for payment failures),
    /// add one entry to the <see cref="Transitions"/> dictionary.
    /// </summary>
    public static class SubscriptionStateMachine
    {
        public const int ReactivationWindowDays = 30;

        // Transition table: (From, To) → optional guard returning (allowed, reason)
        private static readonly Dictionary<(SubscriptionStatus From, SubscriptionStatus To),
            Func<Subscription, (bool Allowed, string? Reason)>?> Transitions = new()
        {
            [(SubscriptionStatus.Active, SubscriptionStatus.Canceled)] = null, // always allowed
            [(SubscriptionStatus.PastDue, SubscriptionStatus.Canceled)] = null, // always allowed
            [(SubscriptionStatus.Canceled, SubscriptionStatus.Active)] = sub =>
            {
                if (!sub.EndDate.HasValue)
                    return (false, "Subscription has no cancellation date recorded.");

                var daysSinceCanceled = (DateTimeOffset.UtcNow - sub.EndDate.Value).TotalDays;
                return daysSinceCanceled <= ReactivationWindowDays
                    ? (true, null)
                    : (false, $"Subscription was canceled more than {ReactivationWindowDays} days ago "
                            + $"(canceled on {sub.EndDate.Value:O}). Reactivation is no longer allowed.");
            }
        };

        /// <summary>
        /// Check whether a transition is allowed for the given subscription.
        /// Returns (true, null) if allowed, (false, reason) if not.
        /// </summary>
        public static (bool Allowed, string? Reason) CanTransition(
            Subscription subscription, SubscriptionStatus to)
        {
            var key = (subscription.Status, to);

            if (!Transitions.TryGetValue(key, out var guard))
                return (false, $"Transition from {subscription.Status} to {to} is not allowed.");

            if (guard is null)
                return (true, null); // no guard → always allowed

            return guard(subscription);
        }

        /// <summary>
        /// Returns all target statuses reachable from the given status.
        /// Useful for documentation / API discoverability.
        /// </summary>
        public static IReadOnlyList<SubscriptionStatus> GetAllowedTargets(SubscriptionStatus from)
        {
            return Transitions.Keys
                .Where(k => k.From == from)
                .Select(k => k.To)
                .ToList();
        }
    }
}
