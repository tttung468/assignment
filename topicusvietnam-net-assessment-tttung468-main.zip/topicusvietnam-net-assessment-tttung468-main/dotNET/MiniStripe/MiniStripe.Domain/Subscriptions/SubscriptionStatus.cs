﻿namespace MiniStripe.Domain.Subscriptions
{
    public enum SubscriptionStatus
    {
        Active = 0,
        PastDue = 1,
        Canceled = 2
    }
}
