namespace MiniStripe.Domain.Exceptions
{
    /// <summary>
    /// Thrown when an optimistic concurrency conflict is detected during a state transition.
    /// Clients should re-read the subscription and retry if appropriate.
    /// </summary>
    public class ConcurrencyConflictException : Exception
    {
        public ConcurrencyConflictException()
            : base("The subscription was modified by another request. Please retry.") { }

        public ConcurrencyConflictException(string message) : base(message) { }

        public ConcurrencyConflictException(string message, Exception inner) : base(message, inner) { }
    }
}
