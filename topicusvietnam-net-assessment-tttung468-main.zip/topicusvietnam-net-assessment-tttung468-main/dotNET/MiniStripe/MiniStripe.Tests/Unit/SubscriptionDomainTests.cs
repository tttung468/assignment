using FluentAssertions;
using MiniStripe.Domain.Subscriptions;

namespace MiniStripe.Tests.Unit
{
    /// <summary>
    /// Unit tests for <see cref="Subscription.TransitionTo"/> domain method.
    /// Tests the entity's state mutation logic in isolation (no database).
    /// </summary>
    public class SubscriptionDomainTests
    {
        [Fact]
        public void TransitionTo_Canceled_FromActive_ReturnsTrue_SetsEndDate()
        {
            // Arrange
            var sub = new Subscription { Status = SubscriptionStatus.Active };

            // Act
            var changed = sub.TransitionTo(SubscriptionStatus.Canceled);

            // Assert
            changed.Should().BeTrue();
            sub.Status.Should().Be(SubscriptionStatus.Canceled);
            sub.EndDate.Should().NotBeNull();
            sub.EndDate.Should().BeCloseTo(DateTimeOffset.UtcNow, TimeSpan.FromSeconds(5));
        }

        [Fact]
        public void TransitionTo_Canceled_FromPastDue_ReturnsTrue()
        {
            // Arrange
            var sub = new Subscription { Status = SubscriptionStatus.PastDue };

            // Act
            var changed = sub.TransitionTo(SubscriptionStatus.Canceled);

            // Assert
            changed.Should().BeTrue();
            sub.Status.Should().Be(SubscriptionStatus.Canceled);
            sub.EndDate.Should().NotBeNull();
        }

        [Fact]
        public void TransitionTo_Canceled_FromCanceled_ReturnsFalse_NoOp()
        {
            // Arrange
            var originalEndDate = DateTimeOffset.UtcNow.AddDays(-5);
            var sub = new Subscription
            {
                Status = SubscriptionStatus.Canceled,
                EndDate = originalEndDate,
                Version = 3
            };

            // Act
            var changed = sub.TransitionTo(SubscriptionStatus.Canceled);

            // Assert — no-op, nothing changes
            changed.Should().BeFalse();
            sub.Status.Should().Be(SubscriptionStatus.Canceled);
            sub.EndDate.Should().Be(originalEndDate);
            sub.Version.Should().Be(3);
        }

        [Fact]
        public void TransitionTo_Active_FromCanceled_Within30Days_ReturnsTrue_ClearsEndDate()
        {
            // Arrange
            var sub = new Subscription
            {
                Status = SubscriptionStatus.Canceled,
                EndDate = DateTimeOffset.UtcNow.AddDays(-10)
            };

            // Act
            var changed = sub.TransitionTo(SubscriptionStatus.Active);

            // Assert
            changed.Should().BeTrue();
            sub.Status.Should().Be(SubscriptionStatus.Active);
            sub.EndDate.Should().BeNull();
        }

        [Fact]
        public void TransitionTo_Active_FromCanceled_After30Days_Throws()
        {
            // Arrange
            var sub = new Subscription
            {
                Status = SubscriptionStatus.Canceled,
                EndDate = DateTimeOffset.UtcNow.AddDays(-31)
            };

            // Act
            var act = () => sub.TransitionTo(SubscriptionStatus.Active);

            // Assert
            act.Should().Throw<InvalidOperationException>()
                .WithMessage("*Reactivation is no longer allowed*");
        }

        [Fact]
        public void TransitionTo_Active_FromActive_ReturnsFalse_NoOp()
        {
            // Arrange
            var sub = new Subscription
            {
                Status = SubscriptionStatus.Active,
                Version = 1
            };

            // Act
            var changed = sub.TransitionTo(SubscriptionStatus.Active);

            // Assert
            changed.Should().BeFalse();
            sub.Version.Should().Be(1);
        }

        [Fact]
        public void TransitionTo_IncrementsVersion()
        {
            // Arrange
            var sub = new Subscription
            {
                Status = SubscriptionStatus.Active,
                Version = 0
            };

            // Act
            sub.TransitionTo(SubscriptionStatus.Canceled);

            // Assert
            sub.Version.Should().Be(1);
        }
    }
}
