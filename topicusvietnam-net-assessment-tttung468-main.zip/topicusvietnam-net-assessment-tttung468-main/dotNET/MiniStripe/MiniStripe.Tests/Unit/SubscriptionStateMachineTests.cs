using FluentAssertions;
using MiniStripe.Domain.Subscriptions;

namespace MiniStripe.Tests.Unit
{
    /// <summary>
    /// Unit tests for <see cref="SubscriptionStateMachine"/>.
    /// Tests the centralized transition rules in isolation (no database).
    /// </summary>
    public class SubscriptionStateMachineTests
    {
        #region CanTransition

        [Fact]
        public void CanTransition_ActiveToCanceled_ReturnsAllowed()
        {
            // Arrange
            var sub = new Subscription { Status = SubscriptionStatus.Active };

            // Act
            var (allowed, reason) = SubscriptionStateMachine.CanTransition(sub, SubscriptionStatus.Canceled);

            // Assert
            allowed.Should().BeTrue();
            reason.Should().BeNull();
        }

        [Fact]
        public void CanTransition_PastDueToCanceled_ReturnsAllowed()
        {
            // Arrange
            var sub = new Subscription { Status = SubscriptionStatus.PastDue };

            // Act
            var (allowed, reason) = SubscriptionStateMachine.CanTransition(sub, SubscriptionStatus.Canceled);

            // Assert
            allowed.Should().BeTrue();
            reason.Should().BeNull();
        }

        [Fact]
        public void CanTransition_CanceledToActive_Within30Days_ReturnsAllowed()
        {
            // Arrange
            var sub = new Subscription
            {
                Status = SubscriptionStatus.Canceled,
                EndDate = DateTimeOffset.UtcNow.AddDays(-10)
            };

            // Act
            var (allowed, reason) = SubscriptionStateMachine.CanTransition(sub, SubscriptionStatus.Active);

            // Assert
            allowed.Should().BeTrue();
            reason.Should().BeNull();
        }

        [Fact]
        public void CanTransition_CanceledToActive_After30Days_ReturnsNotAllowedWithReason()
        {
            // Arrange
            var sub = new Subscription
            {
                Status = SubscriptionStatus.Canceled,
                EndDate = DateTimeOffset.UtcNow.AddDays(-31)
            };

            // Act
            var (allowed, reason) = SubscriptionStateMachine.CanTransition(sub, SubscriptionStatus.Active);

            // Assert
            allowed.Should().BeFalse();
            reason.Should().Contain("30");
            reason.Should().Contain("Reactivation is no longer allowed");
        }

        [Fact]
        public void CanTransition_CanceledToActive_NoEndDate_ReturnsNotAllowed()
        {
            // Arrange
            var sub = new Subscription
            {
                Status = SubscriptionStatus.Canceled,
                EndDate = null
            };

            // Act
            var (allowed, reason) = SubscriptionStateMachine.CanTransition(sub, SubscriptionStatus.Active);

            // Assert
            allowed.Should().BeFalse();
            reason.Should().Contain("no cancellation date");
        }

        [Fact]
        public void CanTransition_ActiveToActive_ReturnsNotAllowed()
        {
            // Arrange
            var sub = new Subscription { Status = SubscriptionStatus.Active };

            // Act
            var (allowed, reason) = SubscriptionStateMachine.CanTransition(sub, SubscriptionStatus.Active);

            // Assert
            allowed.Should().BeFalse();
            reason.Should().Contain("not allowed");
        }

        [Fact]
        public void CanTransition_ActiveToPastDue_ReturnsNotAllowed()
        {
            // Arrange — PastDue transition not yet registered (extensibility proof)
            var sub = new Subscription { Status = SubscriptionStatus.Active };

            // Act
            var (allowed, reason) = SubscriptionStateMachine.CanTransition(sub, SubscriptionStatus.PastDue);

            // Assert
            allowed.Should().BeFalse();
            reason.Should().Contain("not allowed");
        }

        #endregion

        #region GetAllowedTargets

        [Fact]
        public void GetAllowedTargets_FromActive_ReturnsCanceled()
        {
            // Act
            var targets = SubscriptionStateMachine.GetAllowedTargets(SubscriptionStatus.Active);

            // Assert
            targets.Should().ContainSingle()
                .Which.Should().Be(SubscriptionStatus.Canceled);
        }

        [Fact]
        public void GetAllowedTargets_FromCanceled_ReturnsActive()
        {
            // Act
            var targets = SubscriptionStateMachine.GetAllowedTargets(SubscriptionStatus.Canceled);

            // Assert
            targets.Should().ContainSingle()
                .Which.Should().Be(SubscriptionStatus.Active);
        }

        #endregion
    }
}
