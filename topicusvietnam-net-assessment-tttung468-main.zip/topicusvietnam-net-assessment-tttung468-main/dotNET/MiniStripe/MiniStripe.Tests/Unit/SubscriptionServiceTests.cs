﻿using FluentAssertions;
using Microsoft.EntityFrameworkCore;
using MiniStripe.Application.Services;
using MiniStripe.Domain.Customers;
using MiniStripe.Domain.Plans;
using MiniStripe.Domain.Subscriptions;
using MiniStripe.Tests.Helpers;

namespace MiniStripe.Tests.Unit
{
    /// <summary>
    /// Unit tests for <see cref="SubscriptionService"/>.
    /// Tests use an in-memory SQLite database and follow the Arrange-Act-Assert pattern.
    /// </summary>
    public class SubscriptionServiceTests : IDisposable
    {
        private readonly Infrastructure.Persistence.AppDbContext _db;
        private readonly SubscriptionService _sut;

        public SubscriptionServiceTests()
        {
            _db = TestDbContextFactory.Create();
            _sut = new SubscriptionService(_db);
        }

        public void Dispose() => _db.Dispose();

        #region Helpers

        /// <summary>
        /// Seeds a <see cref="Customer"/> and a <see cref="Plan"/> into the in-memory database.
        /// Returns both entities so tests can reference their Ids.
        /// </summary>
        private async Task<(Customer customer, Plan plan)> SeedCustomerAndPlanAsync()
        {
            var customer = new Customer { Email = "test@example.com", Name = "Test User" };
            var plan = new Plan { Code = "basic-monthly", Name = "Basic", Price = 9.99m };
            _db.Customers.Add(customer);
            _db.Plans.Add(plan);
            await _db.SaveChangesAsync();
            return (customer, plan);
        }

        #endregion

        [Fact]
        public async Task CreateAsync_ValidInput_CreatesAndPersistsSubscription()
        {
            // Arrange — seed a valid customer and plan
            var (customer, plan) = await SeedCustomerAndPlanAsync();

            // Act — create a subscription through the service
            var sub = await _sut.CreateAsync(customer.Id, plan.Id, CancellationToken.None);

            // Assert — subscription is created with correct fields and persisted to DB
            sub.Should().NotBeNull();
            sub.CustomerId.Should().Be(customer.Id);
            sub.PlanId.Should().Be(plan.Id);
            sub.Status.Should().Be(SubscriptionStatus.Active);
            sub.StartDate.Should().BeCloseTo(DateTimeOffset.UtcNow, TimeSpan.FromSeconds(5));
            sub.EndDate.Should().BeNull();

            var fromDb = await _db.Subscriptions.FindAsync(sub.Id);
            fromDb.Should().NotBeNull();
        }

        [Fact]
        public async Task CreateAsync_CustomerNotFound_ThrowsInvalidOperationException()
        {
            // Arrange — seed only a plan; use a random GUID for customer
            var (_, plan) = await SeedCustomerAndPlanAsync();
            var nonExistentCustomerId = Guid.NewGuid();

            // Act — attempt to create a subscription with a non-existent customer
            var act = () => _sut.CreateAsync(nonExistentCustomerId, plan.Id, CancellationToken.None);

            // Assert — service rejects the request with a descriptive error
            await act.Should().ThrowAsync<InvalidOperationException>()
                .WithMessage("*Customer not found*");
        }

        [Fact]
        public async Task CreateAsync_PlanNotFound_ThrowsInvalidOperationException()
        {
            // Arrange — seed only a customer; use a random GUID for plan
            var (customer, _) = await SeedCustomerAndPlanAsync();
            var nonExistentPlanId = Guid.NewGuid();

            // Act — attempt to create a subscription with a non-existent plan
            var act = () => _sut.CreateAsync(customer.Id, nonExistentPlanId, CancellationToken.None);

            // Assert — service rejects the request with a descriptive error
            await act.Should().ThrowAsync<InvalidOperationException>()
                .WithMessage("*Plan not found*");
        }

        [Fact]
        public async Task PrepareAsync_AddsSubscriptionToContext_ButDoesNotPersist()
        {
            // Arrange — seed a valid customer and plan
            var (customer, plan) = await SeedCustomerAndPlanAsync();

            // Act — prepare (but do NOT save) a subscription
            var sub = await _sut.PrepareAsync(customer.Id, plan.Id, CancellationToken.None);

            // Assert — entity is valid and tracked, but caller controls when to persist
            sub.Should().NotBeNull();
            sub.Id.Should().NotBeEmpty();
            sub.Status.Should().Be(SubscriptionStatus.Active);
        }

        #region Cancel

        [Fact]
        public async Task CancelAsync_ActiveSubscription_SetsCanceledAndEndDate()
        {
            // Arrange — create an active subscription
            var (customer, plan) = await SeedCustomerAndPlanAsync();
            var sub = await _sut.CreateAsync(customer.Id, plan.Id, CancellationToken.None);

            // Act
            var result = await _sut.CancelAsync(sub.Id, CancellationToken.None);

            // Assert
            result.Status.Should().Be(SubscriptionStatus.Canceled);
            result.EndDate.Should().NotBeNull();
            result.EndDate.Should().BeCloseTo(DateTimeOffset.UtcNow, TimeSpan.FromSeconds(5));

            var audit = await _db.SubscriptionAuditRecords
                .FirstOrDefaultAsync(a => a.SubscriptionId == sub.Id);
            audit.Should().NotBeNull();
            audit!.FromStatus.Should().Be(SubscriptionStatus.Active);
            audit.ToStatus.Should().Be(SubscriptionStatus.Canceled);
            audit.Action.Should().Be("cancel");
        }

        [Fact]
        public async Task CancelAsync_PastDueSubscription_SetsCanceled()
        {
            // Arrange — create a subscription and manually set it to PastDue
            var (customer, plan) = await SeedCustomerAndPlanAsync();
            var sub = await _sut.CreateAsync(customer.Id, plan.Id, CancellationToken.None);
            sub.Status = SubscriptionStatus.PastDue;
            await _db.SaveChangesAsync();

            // Act
            var result = await _sut.CancelAsync(sub.Id, CancellationToken.None);

            // Assert
            result.Status.Should().Be(SubscriptionStatus.Canceled);
            result.EndDate.Should().NotBeNull();
        }

        [Fact]
        public async Task CancelAsync_AlreadyCanceled_IsIdempotent_NoAuditRecord()
        {
            // Arrange — create and cancel a subscription
            var (customer, plan) = await SeedCustomerAndPlanAsync();
            var sub = await _sut.CreateAsync(customer.Id, plan.Id, CancellationToken.None);
            await _sut.CancelAsync(sub.Id, CancellationToken.None);
            var originalEndDate = sub.EndDate;

            // Act — cancel again
            var result = await _sut.CancelAsync(sub.Id, CancellationToken.None);

            // Assert — idempotent, EndDate unchanged, only one audit record
            result.Status.Should().Be(SubscriptionStatus.Canceled);
            result.EndDate.Should().Be(originalEndDate);

            var auditCount = await _db.SubscriptionAuditRecords
                .CountAsync(a => a.SubscriptionId == sub.Id && a.Action == "cancel");
            auditCount.Should().Be(1);
        }

        [Fact]
        public async Task CancelAsync_NotFound_ThrowsKeyNotFoundException()
        {
            // Arrange
            var nonExistentId = Guid.NewGuid();

            // Act
            var act = () => _sut.CancelAsync(nonExistentId, CancellationToken.None);

            // Assert
            await act.Should().ThrowAsync<KeyNotFoundException>()
                .WithMessage("*Subscription not found*");
        }

        #endregion

        #region Reactivate

        [Fact]
        public async Task ReactivateAsync_RecentlyCanceled_SetsActiveAndClearsEndDate()
        {
            // Arrange — create, cancel (EndDate = now), then reactivate
            var (customer, plan) = await SeedCustomerAndPlanAsync();
            var sub = await _sut.CreateAsync(customer.Id, plan.Id, CancellationToken.None);
            await _sut.CancelAsync(sub.Id, CancellationToken.None);

            // Act
            var result = await _sut.ReactivateAsync(sub.Id, CancellationToken.None);

            // Assert
            result.Status.Should().Be(SubscriptionStatus.Active);
            result.EndDate.Should().BeNull();

            var audit = await _db.SubscriptionAuditRecords
                .FirstOrDefaultAsync(a => a.SubscriptionId == sub.Id && a.Action == "reactivate");
            audit.Should().NotBeNull();
            audit!.FromStatus.Should().Be(SubscriptionStatus.Canceled);
            audit.ToStatus.Should().Be(SubscriptionStatus.Active);
        }

        [Fact]
        public async Task ReactivateAsync_CanceledOver30Days_ThrowsInvalidOperation()
        {
            // Arrange — create, cancel, then backdate EndDate
            var (customer, plan) = await SeedCustomerAndPlanAsync();
            var sub = await _sut.CreateAsync(customer.Id, plan.Id, CancellationToken.None);
            await _sut.CancelAsync(sub.Id, CancellationToken.None);
            sub.EndDate = DateTimeOffset.UtcNow.AddDays(-31);
            await _db.SaveChangesAsync();

            // Act
            var act = () => _sut.ReactivateAsync(sub.Id, CancellationToken.None);

            // Assert
            await act.Should().ThrowAsync<InvalidOperationException>()
                .WithMessage("*Reactivation is no longer allowed*");
        }

        [Fact]
        public async Task ReactivateAsync_ActiveSubscription_ThrowsInvalidOperation()
        {
            // Arrange — create an active subscription (not canceled)
            var (customer, plan) = await SeedCustomerAndPlanAsync();
            var sub = await _sut.CreateAsync(customer.Id, plan.Id, CancellationToken.None);

            // Act
            var act = () => _sut.ReactivateAsync(sub.Id, CancellationToken.None);

            // Assert
            await act.Should().ThrowAsync<InvalidOperationException>()
                .WithMessage("*not allowed*");
        }

        [Fact]
        public async Task ReactivateAsync_NotFound_ThrowsKeyNotFoundException()
        {
            // Arrange
            var nonExistentId = Guid.NewGuid();

            // Act
            var act = () => _sut.ReactivateAsync(nonExistentId, CancellationToken.None);

            // Assert
            await act.Should().ThrowAsync<KeyNotFoundException>()
                .WithMessage("*Subscription not found*");
        }

        #endregion
    }
}

