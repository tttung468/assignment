using FluentAssertions;
using Microsoft.EntityFrameworkCore;
using MiniStripe.Domain.Idempotency;
using MiniStripe.Infrastructure.Persistence;
using MiniStripe.Infrastructure.Services;
using MiniStripe.Tests.Helpers;

namespace MiniStripe.Tests.Unit
{
    /// <summary>
    /// Unit tests for <see cref="IdempotencyCleanupService.CleanupExpiredRecordsAsync"/>.
    /// Tests use an in-memory SQLite database and call the extracted static cleanup method
    /// directly, following the Arrange-Act-Assert pattern.
    /// </summary>
    public class IdempotencyCleanupServiceTests : IDisposable
    {
        private readonly AppDbContext _db;

        public IdempotencyCleanupServiceTests()
        {
            _db = TestDbContextFactory.Create();
        }

        public void Dispose() => _db.Dispose();

        #region Helpers

        /// <summary>
        /// Seeds an <see cref="IdempotencyRecord"/> with the given key and expiry offset.
        /// Positive <paramref name="expiresInHours"/> = still valid, negative = expired.
        /// </summary>
        private void SeedRecord(string key, double expiresInHours)
        {
            _db.IdempotencyRecords.Add(new IdempotencyRecord
            {
                IdempotencyKey = key,
                RequestHash = "hash",
                ResponseStatusCode = 201,
                ResponseBody = "{}",
                ExpiresAt = DateTimeOffset.UtcNow.AddHours(expiresInHours)
            });
        }

        #endregion

        [Fact]
        public async Task CleanupExpiredRecordsAsync_AllExpired_DeletesAllRecords()
        {
            // Arrange — seed two expired records
            SeedRecord("expired-1", expiresInHours: -2);
            SeedRecord("expired-2", expiresInHours: -1);
            await _db.SaveChangesAsync();

            // Act — invoke the extracted cleanup method on the service
            var deleted = await IdempotencyCleanupService.CleanupExpiredRecordsAsync(_db);

            // Assert — both records removed, nothing left in DB
            deleted.Should().Be(2);
            var remaining = await _db.IdempotencyRecords.CountAsync();
            remaining.Should().Be(0);
        }

        [Fact]
        public async Task CleanupExpiredRecordsAsync_MixOfExpiredAndValid_OnlyDeletesExpired()
        {
            // Arrange — seed one valid and one expired record
            SeedRecord("valid-1", expiresInHours: 23);
            SeedRecord("expired-1", expiresInHours: -1);
            await _db.SaveChangesAsync();

            // Act — invoke the extracted cleanup method on the service
            var deleted = await IdempotencyCleanupService.CleanupExpiredRecordsAsync(_db);

            // Assert — only the expired record is deleted; the valid one remains
            deleted.Should().Be(1);
            var remaining = await _db.IdempotencyRecords.CountAsync();
            remaining.Should().Be(1);

            var kept = await _db.IdempotencyRecords.FirstAsync();
            kept.IdempotencyKey.Should().Be("valid-1");
        }

        [Fact]
        public async Task CleanupExpiredRecordsAsync_NoRecords_ReturnsZero()
        {
            // Arrange — empty database, no records seeded

            // Act
            var deleted = await IdempotencyCleanupService.CleanupExpiredRecordsAsync(_db);

            // Assert — nothing to delete
            deleted.Should().Be(0);
        }

        [Fact]
        public async Task CleanupExpiredRecordsAsync_AllValid_DeletesNothing()
        {
            // Arrange — seed two records that have not yet expired
            SeedRecord("valid-1", expiresInHours: 10);
            SeedRecord("valid-2", expiresInHours: 23);
            await _db.SaveChangesAsync();

            // Act
            var deleted = await IdempotencyCleanupService.CleanupExpiredRecordsAsync(_db);

            // Assert — no records deleted, both remain
            deleted.Should().Be(0);
            var remaining = await _db.IdempotencyRecords.CountAsync();
            remaining.Should().Be(2);
        }
    }
}
