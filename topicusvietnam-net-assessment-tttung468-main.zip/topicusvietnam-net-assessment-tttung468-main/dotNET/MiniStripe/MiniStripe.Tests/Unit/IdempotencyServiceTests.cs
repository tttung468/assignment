﻿using FluentAssertions;
using Microsoft.EntityFrameworkCore;
using MiniStripe.Application.Services;
using MiniStripe.Domain.Idempotency;
using MiniStripe.Tests.Helpers;

namespace MiniStripe.Tests.Unit
{
    /// <summary>
    /// Unit tests for <see cref="IdempotencyService"/>.
    /// Tests use an in-memory SQLite database and follow the Arrange-Act-Assert pattern.
    /// </summary>
    public class IdempotencyServiceTests : IDisposable
    {
        private readonly Infrastructure.Persistence.AppDbContext _db;
        private readonly IdempotencyService _sut;

        public IdempotencyServiceTests()
        {
            _db = TestDbContextFactory.Create();
            _sut = new IdempotencyService(_db);
        }

        public void Dispose() => _db.Dispose();

        #region Helpers

        /// <summary>
        /// Seeds an <see cref="IdempotencyRecord"/> with the given key, hash, and expiry offset.
        /// Positive <paramref name="expiresInHours"/> = still valid, negative = expired.
        /// </summary>
        private async Task SeedRecordAsync(
            string key,
            string hash,
            double expiresInHours,
            int statusCode = 201,
            string body = "{}")
        {
            _db.IdempotencyRecords.Add(new IdempotencyRecord
            {
                IdempotencyKey = key,
                RequestHash = hash,
                ResponseStatusCode = statusCode,
                ResponseBody = body,
                ExpiresAt = DateTimeOffset.UtcNow.AddHours(expiresInHours)
            });
            await _db.SaveChangesAsync();
        }

        #endregion

        [Fact]
        public async Task TryGetExistingAsync_NoRecord_ReturnsNull()
        {
            // Arrange — no records in the database

            // Act — look up a key that does not exist
            var result = await _sut.TryGetExistingAsync("non-existent-key", "somehash", CancellationToken.None);

            // Assert — should return null when key is not found
            result.Should().BeNull();
        }

        [Fact]
        public async Task TryGetExistingAsync_ValidRecord_SameHash_ReturnsCachedResponse()
        {
            // Arrange — seed a valid (not expired) idempotency record
            var body = "{\"id\":\"00000000-0000-0000-0000-000000000001\"}";
            await SeedRecordAsync("test-key-1", "hash123", expiresInHours: 24, body: body);

            // Act — look up with matching key and matching hash
            var result = await _sut.TryGetExistingAsync("test-key-1", "hash123", CancellationToken.None);

            // Assert — returns the cached status code and body
            result.Should().NotBeNull();
            result!.Value.StatusCode.Should().Be(201);
            result.Value.Body.Should().Contain("00000000-0000-0000-0000-000000000001");
        }

        [Fact]
        public async Task TryGetExistingAsync_ValidRecord_DifferentHash_ThrowsIdempotencyException()
        {
            // Arrange — seed a valid record with "original-hash"
            await SeedRecordAsync("test-key-2", "original-hash", expiresInHours: 24);

            // Act — look up with the same key but a different request hash
            var act = () => _sut.TryGetExistingAsync("test-key-2", "different-hash", CancellationToken.None);

            // Assert — throws IdempotencyException indicating payload mismatch
            await act.Should().ThrowAsync<IdempotencyException>()
                .WithMessage("*different request payload*");
        }

        [Fact]
        public async Task TryGetExistingAsync_ExpiredRecord_ReturnsNull()
        {
            // Arrange — seed an idempotency record that already expired 1 hour ago
            await SeedRecordAsync("expired-key", "hash", expiresInHours: -1);

            // Act — look up the expired key
            var result = await _sut.TryGetExistingAsync("expired-key", "hash", CancellationToken.None);

            // Assert — expired records are treated as non-existent
            result.Should().BeNull();
        }

        [Fact]
        public async Task PrepareRecord_AddsRecordToContext_AndPersistsOnSave()
        {
            // Arrange — nothing seeded; we will use PrepareRecord to create a new record

            // Act — prepare the record (adds to DbContext but does NOT save)
            _sut.PrepareRecord("prep-key", "prep-hash", 201, "{\"id\":\"test\"}");
            await _db.SaveChangesAsync(); // caller is responsible for saving

            // Assert — record is persisted with correct fields and a 24-hour TTL
            var saved = await _db.IdempotencyRecords.FirstOrDefaultAsync(r => r.IdempotencyKey == "prep-key");
            saved.Should().NotBeNull();
            saved!.RequestHash.Should().Be("prep-hash");
            saved.ResponseStatusCode.Should().Be(201);
            saved.ResponseBody.Should().Be("{\"id\":\"test\"}");
            saved.ExpiresAt.Should().BeCloseTo(DateTimeOffset.UtcNow.AddHours(24), TimeSpan.FromMinutes(1));
        }

        [Fact]
        public void ComputeHash_SameInput_ReturnsSameHash()
        {
            // Arrange — two identical pairs of GUIDs
            var customerId = Guid.Parse("11111111-1111-1111-1111-111111111111");
            var planId = Guid.Parse("22222222-2222-2222-2222-222222222222");

            // Act — compute hash twice with the same input
            var hash1 = IdempotencyService.ComputeHash(customerId, planId);
            var hash2 = IdempotencyService.ComputeHash(customerId, planId);

            // Assert — deterministic: same input always produces the same hash
            hash1.Should().Be(hash2);
        }

        [Fact]
        public void ComputeHash_DifferentInput_ReturnsDifferentHash()
        {
            // Arrange — same customerId but different planIds
            var customerId = Guid.Parse("11111111-1111-1111-1111-111111111111");
            var planId1 = Guid.Parse("22222222-2222-2222-2222-222222222222");
            var planId2 = Guid.Parse("33333333-3333-3333-3333-333333333333");

            // Act — compute hashes with different inputs
            var hash1 = IdempotencyService.ComputeHash(customerId, planId1);
            var hash2 = IdempotencyService.ComputeHash(customerId, planId2);

            // Assert — different inputs produce different hashes
            hash1.Should().NotBe(hash2);
        }
    }
}

