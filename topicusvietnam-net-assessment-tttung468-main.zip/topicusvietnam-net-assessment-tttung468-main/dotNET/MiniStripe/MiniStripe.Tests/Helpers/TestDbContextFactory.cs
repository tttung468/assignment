using Microsoft.EntityFrameworkCore;
using MiniStripe.Infrastructure.Persistence;

namespace MiniStripe.Tests.Helpers
{
    /// <summary>
    /// Creates a fresh in-memory SQLite database for each test.
    /// </summary>
    public static class TestDbContextFactory
    {
        public static AppDbContext Create()
        {
            var options = new DbContextOptionsBuilder<AppDbContext>()
                .UseSqlite("Data Source=:memory:")
                .Options;

            var db = new AppDbContext(options);
            db.Database.OpenConnection();
            db.Database.EnsureCreated();
            return db;
        }
    }
}
