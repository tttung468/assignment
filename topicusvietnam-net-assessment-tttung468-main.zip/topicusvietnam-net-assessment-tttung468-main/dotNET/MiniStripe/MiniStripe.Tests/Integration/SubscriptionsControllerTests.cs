using System.Net;
using System.Net.Http.Json;
using System.Text.Json;
using FluentAssertions;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using MiniStripe.Contracts.Customers;
using MiniStripe.Contracts.Plans;
using MiniStripe.Contracts.Subscriptions;
using MiniStripe.Domain.Subscriptions;
using MiniStripe.Infrastructure.Persistence;

namespace MiniStripe.Tests.Integration
{
    public class SubscriptionsControllerTests : IClassFixture<CustomWebApplicationFactory>, IDisposable
    {
        private readonly CustomWebApplicationFactory _factory;
        private readonly HttpClient _client;

        private static readonly JsonSerializerOptions JsonOptions = new()
        {
            PropertyNameCaseInsensitive = true
        };

        public SubscriptionsControllerTests(CustomWebApplicationFactory factory)
        {
            _factory = factory;
            _client = factory.CreateClient();
        }

        public void Dispose() => _client.Dispose();

        private async Task<(Guid CustomerId, Guid PlanId)> SeedCustomerAndPlan()
        {
            var uniqueEmail = $"test-{Guid.NewGuid():N}@test.com";
            var customerResp = await _client.PostAsJsonAsync("/customers",
                new CreateCustomerRequest(uniqueEmail, "Test User"));
            customerResp.EnsureSuccessStatusCode();
            var customer = await customerResp.Content.ReadFromJsonAsync<CustomerResponse>(JsonOptions);

            var planResp = await _client.PostAsJsonAsync("/plans",
                new CreatePlanRequest($"plan-{Guid.NewGuid():N}", "Test Plan", 19.99m, "EUR", "month"));
            var plan = await planResp.Content.ReadFromJsonAsync<PlanResponse>(JsonOptions);

            return (customer!.Id, plan!.Id);
        }

        [Fact]
        public async Task Post_NoIdempotencyKey_CreatesSubscription()
        {
            var (customerId, planId) = await SeedCustomerAndPlan();

            var response = await _client.PostAsJsonAsync("/subscriptions",
                new CreateSubscriptionRequest(customerId, planId));

            response.StatusCode.Should().Be(HttpStatusCode.Created);
            var sub = await response.Content.ReadFromJsonAsync<SubscriptionResponse>(JsonOptions);
            sub.Should().NotBeNull();
            sub!.CustomerId.Should().Be(customerId);
            sub.PlanId.Should().Be(planId);
        }

        [Fact]
        public async Task Post_WithIdempotencyKey_FirstCall_CreatesSubscription()
        {
            var (customerId, planId) = await SeedCustomerAndPlan();
            var idempotencyKey = Guid.NewGuid().ToString();

            var request = new HttpRequestMessage(HttpMethod.Post, "/subscriptions")
            {
                Content = JsonContent.Create(new CreateSubscriptionRequest(customerId, planId))
            };
            request.Headers.Add("Idempotency-Key", idempotencyKey);

            var response = await _client.SendAsync(request);

            response.StatusCode.Should().Be(HttpStatusCode.Created);
            var sub = await response.Content.ReadFromJsonAsync<SubscriptionResponse>(JsonOptions);
            sub.Should().NotBeNull();
            sub!.CustomerId.Should().Be(customerId);
        }

        [Fact]
        public async Task Post_WithIdempotencyKey_Retry_SamePayload_ReturnsCachedResponse()
        {
            var (customerId, planId) = await SeedCustomerAndPlan();
            var idempotencyKey = Guid.NewGuid().ToString();
            var body = new CreateSubscriptionRequest(customerId, planId);

            // First call
            var req1 = new HttpRequestMessage(HttpMethod.Post, "/subscriptions")
            {
                Content = JsonContent.Create(body)
            };
            req1.Headers.Add("Idempotency-Key", idempotencyKey);
            var resp1 = await _client.SendAsync(req1);
            resp1.StatusCode.Should().Be(HttpStatusCode.Created);
            var sub1 = await resp1.Content.ReadFromJsonAsync<SubscriptionResponse>(JsonOptions);

            // Retry with same key + same payload
            var req2 = new HttpRequestMessage(HttpMethod.Post, "/subscriptions")
            {
                Content = JsonContent.Create(body)
            };
            req2.Headers.Add("Idempotency-Key", idempotencyKey);
            var resp2 = await _client.SendAsync(req2);

            resp2.StatusCode.Should().Be(HttpStatusCode.Created);
            var sub2 = await resp2.Content.ReadFromJsonAsync<SubscriptionResponse>(JsonOptions);

            // Should return the same subscription (cached)
            sub2!.Id.Should().Be(sub1!.Id);

            // Verify only one subscription exists in DB
            using var scope = _factory.Services.CreateScope();
            var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
            var count = await db.Subscriptions.CountAsync(s =>
                s.CustomerId == customerId && s.PlanId == planId);
            count.Should().Be(1);
        }

        [Fact]
        public async Task Post_WithIdempotencyKey_Retry_DifferentPayload_Returns409()
        {
            var (customerId, planId) = await SeedCustomerAndPlan();
            var idempotencyKey = Guid.NewGuid().ToString();

            // First call
            var req1 = new HttpRequestMessage(HttpMethod.Post, "/subscriptions")
            {
                Content = JsonContent.Create(new CreateSubscriptionRequest(customerId, planId))
            };
            req1.Headers.Add("Idempotency-Key", idempotencyKey);
            var resp1 = await _client.SendAsync(req1);
            resp1.StatusCode.Should().Be(HttpStatusCode.Created);

            // Create a different plan for the second call
            var planResp = await _client.PostAsJsonAsync("/plans",
                new CreatePlanRequest($"plan2-{Guid.NewGuid():N}", "Plan 2", 29.99m, "EUR", "month"));
            var plan2 = await planResp.Content.ReadFromJsonAsync<PlanResponse>(JsonOptions);

            // Retry with same key but different payload
            var req2 = new HttpRequestMessage(HttpMethod.Post, "/subscriptions")
            {
                Content = JsonContent.Create(new CreateSubscriptionRequest(customerId, plan2!.Id))
            };
            req2.Headers.Add("Idempotency-Key", idempotencyKey);
            var resp2 = await _client.SendAsync(req2);

            resp2.StatusCode.Should().Be(HttpStatusCode.Conflict);
        }

        [Fact]
        public async Task Post_WithEmptyIdempotencyKey_Returns400()
        {
            var (customerId, planId) = await SeedCustomerAndPlan();

            var request = new HttpRequestMessage(HttpMethod.Post, "/subscriptions")
            {
                Content = JsonContent.Create(new CreateSubscriptionRequest(customerId, planId))
            };
            request.Headers.Add("Idempotency-Key", "   ");

            var response = await _client.SendAsync(request);

            response.StatusCode.Should().Be(HttpStatusCode.BadRequest);
        }

        [Fact]
        public async Task Post_WithTooLongIdempotencyKey_Returns400()
        {
            var (customerId, planId) = await SeedCustomerAndPlan();
            var longKey = new string('x', 257);

            var request = new HttpRequestMessage(HttpMethod.Post, "/subscriptions")
            {
                Content = JsonContent.Create(new CreateSubscriptionRequest(customerId, planId))
            };
            request.Headers.Add("Idempotency-Key", longKey);

            var response = await _client.SendAsync(request);

            response.StatusCode.Should().Be(HttpStatusCode.BadRequest);
        }

        [Fact]
        public async Task Post_WithIdempotencyKey_CustomerNotFound_Returns404_NotCached()
        {
            var (_, planId) = await SeedCustomerAndPlan();
            var idempotencyKey = Guid.NewGuid().ToString();
            var fakeCustomerId = Guid.NewGuid();

            // First call with invalid customer
            var req1 = new HttpRequestMessage(HttpMethod.Post, "/subscriptions")
            {
                Content = JsonContent.Create(new CreateSubscriptionRequest(fakeCustomerId, planId))
            };
            req1.Headers.Add("Idempotency-Key", idempotencyKey);
            var resp1 = await _client.SendAsync(req1);
            resp1.StatusCode.Should().Be(HttpStatusCode.NotFound);

            // Verify no idempotency record was cached
            using var scope = _factory.Services.CreateScope();
            var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
            var records = await db.IdempotencyRecords.CountAsync(r => r.IdempotencyKey == idempotencyKey);
            records.Should().Be(0);
        }

        [Fact]
        public async Task Post_WithIdempotencyKey_PlanNotFound_Returns404_NotCached()
        {
            var (customerId, _) = await SeedCustomerAndPlan();
            var idempotencyKey = Guid.NewGuid().ToString();
            var fakePlanId = Guid.NewGuid();

            var req1 = new HttpRequestMessage(HttpMethod.Post, "/subscriptions")
            {
                Content = JsonContent.Create(new CreateSubscriptionRequest(customerId, fakePlanId))
            };
            req1.Headers.Add("Idempotency-Key", idempotencyKey);
            var resp1 = await _client.SendAsync(req1);
            resp1.StatusCode.Should().Be(HttpStatusCode.NotFound);

            // Verify no idempotency record was cached
            using var scope = _factory.Services.CreateScope();
            var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
            var records = await db.IdempotencyRecords.CountAsync(r => r.IdempotencyKey == idempotencyKey);
            records.Should().Be(0);
        }

        #region Cancel

        /// <summary>
        /// Creates a subscription and returns its ID (helper for cancel/reactivate tests).
        /// </summary>
        private async Task<Guid> CreateSubscriptionAsync(Guid customerId, Guid planId)
        {
            var resp = await _client.PostAsJsonAsync("/subscriptions",
                new CreateSubscriptionRequest(customerId, planId));
            resp.EnsureSuccessStatusCode();
            var sub = await resp.Content.ReadFromJsonAsync<SubscriptionResponse>(JsonOptions);
            return sub!.Id;
        }

        [Fact]
        public async Task Cancel_ActiveSubscription_Returns200_StatusIsCanceled()
        {
            // Arrange
            var (customerId, planId) = await SeedCustomerAndPlan();
            var subId = await CreateSubscriptionAsync(customerId, planId);

            // Act
            var response = await _client.PostAsync($"/subscriptions/{subId}/cancel", null);

            // Assert
            response.StatusCode.Should().Be(HttpStatusCode.OK);
            var sub = await response.Content.ReadFromJsonAsync<SubscriptionResponse>(JsonOptions);
            sub!.Status.Should().Be(SubscriptionStatus.Canceled);
            sub.EndDate.Should().NotBeNull();
        }

        [Fact]
        public async Task Cancel_PastDueSubscription_Returns200()
        {
            // Arrange — create subscription then set to PastDue directly in DB
            var (customerId, planId) = await SeedCustomerAndPlan();
            var subId = await CreateSubscriptionAsync(customerId, planId);

            using (var scope = _factory.Services.CreateScope())
            {
                var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
                var sub = await db.Subscriptions.FindAsync(subId);
                sub!.Status = SubscriptionStatus.PastDue;
                await db.SaveChangesAsync();
            }

            // Act
            var response = await _client.PostAsync($"/subscriptions/{subId}/cancel", null);

            // Assert
            response.StatusCode.Should().Be(HttpStatusCode.OK);
            var result = await response.Content.ReadFromJsonAsync<SubscriptionResponse>(JsonOptions);
            result!.Status.Should().Be(SubscriptionStatus.Canceled);
        }

        [Fact]
        public async Task Cancel_AlreadyCanceled_Returns200_Idempotent()
        {
            // Arrange
            var (customerId, planId) = await SeedCustomerAndPlan();
            var subId = await CreateSubscriptionAsync(customerId, planId);
            await _client.PostAsync($"/subscriptions/{subId}/cancel", null);

            // Act — cancel again
            var response = await _client.PostAsync($"/subscriptions/{subId}/cancel", null);

            // Assert
            response.StatusCode.Should().Be(HttpStatusCode.OK);
            var sub = await response.Content.ReadFromJsonAsync<SubscriptionResponse>(JsonOptions);
            sub!.Status.Should().Be(SubscriptionStatus.Canceled);
        }

        [Fact]
        public async Task Cancel_NonExistent_Returns404()
        {
            // Act
            var response = await _client.PostAsync($"/subscriptions/{Guid.NewGuid()}/cancel", null);

            // Assert
            response.StatusCode.Should().Be(HttpStatusCode.NotFound);
        }

        #endregion

        #region Reactivate

        [Fact]
        public async Task Reactivate_RecentlyCanceled_Returns200_StatusIsActive()
        {
            // Arrange — create and cancel
            var (customerId, planId) = await SeedCustomerAndPlan();
            var subId = await CreateSubscriptionAsync(customerId, planId);
            await _client.PostAsync($"/subscriptions/{subId}/cancel", null);

            // Act
            var response = await _client.PostAsync($"/subscriptions/{subId}/reactivate", null);

            // Assert
            response.StatusCode.Should().Be(HttpStatusCode.OK);
            var sub = await response.Content.ReadFromJsonAsync<SubscriptionResponse>(JsonOptions);
            sub!.Status.Should().Be(SubscriptionStatus.Active);
            sub.EndDate.Should().BeNull();
        }

        [Fact]
        public async Task Reactivate_CanceledTooLongAgo_Returns422_WithMessage()
        {
            // Arrange — create, cancel, then backdate EndDate
            var (customerId, planId) = await SeedCustomerAndPlan();
            var subId = await CreateSubscriptionAsync(customerId, planId);
            await _client.PostAsync($"/subscriptions/{subId}/cancel", null);

            using (var scope = _factory.Services.CreateScope())
            {
                var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
                var sub = await db.Subscriptions.FindAsync(subId);
                sub!.EndDate = DateTimeOffset.UtcNow.AddDays(-31);
                await db.SaveChangesAsync();
            }

            // Act
            var response = await _client.PostAsync($"/subscriptions/{subId}/reactivate", null);

            // Assert
            response.StatusCode.Should().Be(HttpStatusCode.UnprocessableEntity);
            var body = await response.Content.ReadAsStringAsync();
            body.Should().Contain("Reactivation is no longer allowed");
        }

        [Fact]
        public async Task Reactivate_ActiveSubscription_Returns422()
        {
            // Arrange — subscription is already active
            var (customerId, planId) = await SeedCustomerAndPlan();
            var subId = await CreateSubscriptionAsync(customerId, planId);

            // Act
            var response = await _client.PostAsync($"/subscriptions/{subId}/reactivate", null);

            // Assert
            response.StatusCode.Should().Be(HttpStatusCode.UnprocessableEntity);
        }

        [Fact]
        public async Task Reactivate_NonExistent_Returns404()
        {
            // Act
            var response = await _client.PostAsync($"/subscriptions/{Guid.NewGuid()}/reactivate", null);

            // Assert
            response.StatusCode.Should().Be(HttpStatusCode.NotFound);
        }

        #endregion
    }
}
