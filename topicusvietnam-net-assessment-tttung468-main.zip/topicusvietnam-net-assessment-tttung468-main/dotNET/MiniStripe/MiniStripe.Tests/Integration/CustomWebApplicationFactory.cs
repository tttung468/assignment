using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using MiniStripe.Infrastructure.Persistence;

namespace MiniStripe.Tests.Integration
{
    public class CustomWebApplicationFactory : WebApplicationFactory<Program>
    {
        private readonly string _dbName = $"test_{Guid.NewGuid()}.db";

        protected override void ConfigureWebHost(IWebHostBuilder builder)
        {
            builder.ConfigureServices(services =>
            {
                // Remove the existing DbContext registration
                var descriptor = services.SingleOrDefault(
                    d => d.ServiceType == typeof(DbContextOptions<AppDbContext>));
                if (descriptor is not null)
                    services.Remove(descriptor);

                // Use a unique SQLite file per test factory instance
                services.AddDbContext<AppDbContext>(opt =>
                    opt.UseSqlite($"Data Source={_dbName}"));
            });

            builder.UseEnvironment("Testing");
        }

        protected override void Dispose(bool disposing)
        {
            base.Dispose(disposing);

            // Clean up test database (best-effort; file may be locked)
            try
            {
                if (File.Exists(_dbName))
                    File.Delete(_dbName);
            }
            catch (IOException) { }
        }
    }
}
