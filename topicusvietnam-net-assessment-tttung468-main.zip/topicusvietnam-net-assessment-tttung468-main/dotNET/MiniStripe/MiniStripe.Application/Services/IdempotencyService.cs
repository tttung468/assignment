using System.Security.Cryptography;
using System.Text;
using Microsoft.EntityFrameworkCore;
using MiniStripe.Domain.Idempotency;
using MiniStripe.Infrastructure.Persistence;

namespace MiniStripe.Application.Services
{
    public class IdempotencyException : Exception
    {
        public IdempotencyException(string message) : base(message) { }
    }

    public class IdempotencyService
    {
        private readonly AppDbContext _db;
        private static readonly TimeSpan DefaultTtl = TimeSpan.FromHours(24);

        public IdempotencyService(AppDbContext db) => _db = db;

        /// <summary>
        /// Computes a SHA256 hash of the request payload for deduplication.
        /// </summary>
        public static string ComputeHash(Guid customerId, Guid planId)
        {
            var input = $"{customerId}:{planId}";
            var bytes = SHA256.HashData(Encoding.UTF8.GetBytes(input));
            return Convert.ToHexString(bytes);
        }

        /// <summary>
        /// Checks if an idempotency key already exists. 
        /// Returns the cached response if hash matches, throws if hash differs.
        /// Returns null if key not found or expired.
        /// </summary>
        public async Task<(int StatusCode, string Body)?> TryGetExistingAsync(
            string key, string requestHash, CancellationToken ct)
        {
            // Query by key only — SQLite can't translate DateTimeOffset comparisons in LINQ
            var record = await _db.IdempotencyRecords
                .FirstOrDefaultAsync(r => r.IdempotencyKey == key, ct);

            // Check expiry in C# code
            if (record is null || record.ExpiresAt <= DateTimeOffset.UtcNow)
                return null;

            if (record.RequestHash != requestHash)
                throw new IdempotencyException(
                    "Idempotency key has already been used with a different request payload.");

            return (record.ResponseStatusCode, record.ResponseBody);
        }

        /// <summary>
        /// Creates an IdempotencyRecord and adds it to the DbContext (does NOT call SaveChangesAsync).
        /// The caller is responsible for saving as part of a larger transaction.
        /// </summary>
        public void PrepareRecord(string key, string requestHash, int statusCode, string responseBody)
        {
            var record = new IdempotencyRecord
            {
                IdempotencyKey = key,
                RequestHash = requestHash,
                ResponseStatusCode = statusCode,
                ResponseBody = responseBody,
                CreatedAt = DateTimeOffset.UtcNow,
                ExpiresAt = DateTimeOffset.UtcNow.Add(DefaultTtl)
            };

            _db.IdempotencyRecords.Add(record);
        }
    }
}
