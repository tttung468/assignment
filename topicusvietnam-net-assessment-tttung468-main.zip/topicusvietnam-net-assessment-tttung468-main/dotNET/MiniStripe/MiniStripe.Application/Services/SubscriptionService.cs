using Microsoft.EntityFrameworkCore;
using MiniStripe.Domain.Exceptions;
using MiniStripe.Domain.Subscriptions;
using MiniStripe.Infrastructure.Persistence;

namespace MiniStripe.Application.Services
{
    public class SubscriptionService
    {
        private readonly AppDbContext _db;

        public SubscriptionService(AppDbContext db) => _db = db;

        /// <summary>
        /// Validates inputs and builds a Subscription entity, adding it to the DbContext
        /// but NOT calling SaveChangesAsync. The caller is responsible for saving.
        /// This allows the caller to add additional entities (e.g. IdempotencyRecord)
        /// to the same transaction before saving.
        /// </summary>
        public async Task<Subscription> PrepareAsync(Guid customerId, Guid planId, CancellationToken ct)
        {
            var customerExists = await _db.Customers.AnyAsync(x => x.Id == customerId, ct);
            if (!customerExists) throw new InvalidOperationException("Customer not found.");

            var planExists = await _db.Plans.AnyAsync(x => x.Id == planId, ct);
            if (!planExists) throw new InvalidOperationException("Plan not found.");

            var sub = new Subscription
            {
                CustomerId = customerId,
                PlanId = planId,
                Status = SubscriptionStatus.Active,
                StartDate = DateTimeOffset.UtcNow
            };

            _db.Subscriptions.Add(sub);

            return sub;
        }

        /// <summary>
        /// Creates a new subscription and saves it immediately.
        /// Use this when no idempotency record is needed.
        /// </summary>
        public async Task<Subscription> CreateAsync(Guid customerId, Guid planId, CancellationToken ct)
        {
            var sub = await PrepareAsync(customerId, planId, ct);
            await _db.SaveChangesAsync(ct);
            return sub;
        }

        /// <summary>
        /// Cancels a subscription. Idempotent: canceling an already-canceled subscription is a no-op.
        /// </summary>
        public async Task<Subscription> CancelAsync(Guid subscriptionId, CancellationToken ct)
        {
            var sub = await _db.Subscriptions.FindAsync([subscriptionId], ct)
                ?? throw new KeyNotFoundException("Subscription not found.");

            var fromStatus = sub.Status;
            var changed = sub.TransitionTo(SubscriptionStatus.Canceled);

            if (changed)
            {
                _db.SubscriptionAuditRecords.Add(new SubscriptionAuditRecord
                {
                    SubscriptionId = sub.Id,
                    FromStatus = fromStatus,
                    ToStatus = SubscriptionStatus.Canceled,
                    Action = "cancel"
                });

                try
                {
                    await _db.SaveChangesAsync(ct);
                }
                catch (DbUpdateConcurrencyException ex)
                {
                    throw new ConcurrencyConflictException(
                        "The subscription was modified by another request. Please retry.", ex);
                }
            }

            return sub;
        }

        /// <summary>
        /// Reactivates a canceled subscription. Only allowed within 30 days of EndDate.
        /// </summary>
        public async Task<Subscription> ReactivateAsync(Guid subscriptionId, CancellationToken ct)
        {
            var sub = await _db.Subscriptions.FindAsync([subscriptionId], ct)
                ?? throw new KeyNotFoundException("Subscription not found.");

            // Reactivation is only meaningful from Canceled state.
            // Unlike cancel (which is idempotent), reactivating a non-canceled
            // subscription is a client error — the caller has stale state.
            if (sub.Status != SubscriptionStatus.Canceled)
                throw new InvalidOperationException(
                    $"Transition from {sub.Status} to {SubscriptionStatus.Active} is not allowed.");

            var fromStatus = sub.Status;
            sub.TransitionTo(SubscriptionStatus.Active); // throws if guard rejects (e.g. >30 days)

            _db.SubscriptionAuditRecords.Add(new SubscriptionAuditRecord
            {
                SubscriptionId = sub.Id,
                FromStatus = fromStatus,
                ToStatus = SubscriptionStatus.Active,
                Action = "reactivate"
            });

            try
            {
                await _db.SaveChangesAsync(ct);
            }
            catch (DbUpdateConcurrencyException ex)
            {
                throw new ConcurrencyConflictException(
                    "The subscription was modified by another request. Please retry.", ex);
            }

            return sub;
        }
    }
}
